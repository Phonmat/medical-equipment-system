import React, { useRef, useMemo, useState } from 'react';
import { Printer, X, FileText, Loader2, ExternalLink } from 'lucide-react';
import { RepairJob, Equipment } from '../types';
import { formatDateSlash, parseDateString } from '../utils/dateUtils';
import { printElement, printInNewWindow } from '../utils/printUtils';
import { useAppStore } from '../store';

interface RepairReportModalProps {
  repair: RepairJob | null;
  equipment?: Equipment;
  isOpen: boolean;
  onClose: () => void;
}

export default function RepairReportModal({ repair, equipment, isOpen, onClose }: RepairReportModalProps) {
  const printContentRef = useRef<HTMLDivElement>(null);
  const { equipment: allEquipment = [], repairs = [], userRole } = useAppStore();
  const isAdmin = userRole === 'Super Admin' || userRole === 'Admin';

  // ตรวจสอบว่าเป็นเครื่องนอกทะเบียนหรือไม่
  const isNonRegistered = Boolean(
    repair?.isNonRegistered ||
    repair?.equipmentId === 'NON_REGISTERED' ||
    repair?.equipmentId?.startsWith('non-reg-') ||
    repair?.equipmentCode === 'นอกทะเบียน' ||
    (!equipment && !allEquipment.some(e => e.id === repair?.equipmentId))
  );

  // ค้นหาข้อมูลเครื่องมือในระบบ (เฉพาะกรณีที่เป็นเครื่องในทะเบียน)
  const targetEq = !isNonRegistered
    ? (equipment || allEquipment.find(e => e.id === repair?.equipmentId || (repair?.equipmentCode && (e.code === repair.equipmentCode || e.itrisId === repair.equipmentCode))))
    : undefined;

  // หากเป็นเครื่องนอกทะเบียน ให้นำข้อมูลเครื่องมาจากการเปิดงานซ่อม (repair) โดยตรง
  const displayName = isNonRegistered
    ? (repair?.equipmentName || 'ไม่ระบุชื่อเครื่องมือ')
    : (targetEq?.name || repair?.equipmentName || 'ไม่ระบุชื่อเครื่องมือ');

  const displayCode = isNonRegistered
    ? (repair?.equipmentCode || 'นอกทะเบียน')
    : (repair?.equipmentCode || targetEq?.code || targetEq?.itrisId || '-');

  const displaySerial = isNonRegistered
    ? (repair?.serialNumber || '-')
    : (targetEq?.serialNumber || repair?.serialNumber || '-');

  const displayModel = isNonRegistered
    ? (repair?.model || '-')
    : (targetEq?.model || repair?.model || '-');

  const displayManufacturer = isNonRegistered
    ? (repair?.manufacturer || '-')
    : (targetEq?.manufacturer || repair?.manufacturer || '-');

  const displayDepartment = isNonRegistered
    ? (repair?.department || '-')
    : (repair?.department || targetEq?.department || '-');

  const deviceDescription = displayCode && displayName ? `${displayCode} - ${displayName}` : (displayCode || displayName || 'ไม่ระบุชื่อเครื่องมือ');

  // Format Report No.: วันที่.เดือน/ลำดับการเปิดงานของวันนั้นๆเรียงตามลำดับ (ตัวอย่างเช่น 12.9/1)
  const reportNumber = useMemo(() => {
    if (!repair) return 'REPORT';

    // วันที่เปิดงาน: ใช้ reportDate หรือ signatureDate หากไม่มีใช้วันปัจจุบัน
    const rawDate = repair.reportDate || repair.signatureDate || new Date().toISOString().split('T')[0];
    const parsed = parseDateString(rawDate);

    let year = 0;
    let month = 0;
    let day = 0;
    let targetIsoDate = '';

    if (parsed && /^\d{4}-\d{2}-\d{2}$/.test(parsed)) {
      const [y, m, d] = parsed.split('-').map(Number);
      year = y;
      month = m;
      day = d;
      targetIsoDate = parsed;
    } else {
      const dt = new Date(rawDate);
      if (!isNaN(dt.getTime())) {
        year = dt.getFullYear();
        month = dt.getMonth() + 1;
        day = dt.getDate();
        targetIsoDate = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      } else {
        const now = new Date();
        year = now.getFullYear();
        month = now.getMonth() + 1;
        day = now.getDate();
        targetIsoDate = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      }
    }

    // หารายการแจ้งซ่อมทั้งหมดที่เปิดในวันเดียวกัน
    const sameDayRepairs = repairs.filter(r => {
      const rDate = r.reportDate || r.signatureDate;
      if (!rDate) return false;
      const rParsed = parseDateString(rDate);
      if (rParsed && /^\d{4}-\d{2}-\d{2}$/.test(rParsed)) {
        return rParsed === targetIsoDate;
      }
      const rDt = new Date(rDate);
      if (!isNaN(rDt.getTime())) {
        const rIso = `${rDt.getFullYear()}-${String(rDt.getMonth() + 1).padStart(2, '0')}-${String(rDt.getDate()).padStart(2, '0')}`;
        return rIso === targetIsoDate;
      }
      return false;
    });

    // เรียงลำดับตามเวลาเปิดงาน หรือตามลำดับที่เปิดงานในระบบ
    const sortedSameDay = [...sameDayRepairs].sort((a, b) => {
      if (a.reportTime && b.reportTime && a.reportTime !== b.reportTime) {
        return a.reportTime.localeCompare(b.reportTime);
      }
      const idxA = repairs.findIndex(item => item.id === a.id);
      const idxB = repairs.findIndex(item => item.id === b.id);
      return idxA - idxB;
    });

    // ลำดับที่ของงานซ่อมนี้ในวันดังกล่าว (เริ่มนับจาก 1)
    const foundIdx = sortedSameDay.findIndex(item => item.id === repair.id);
    const seq = foundIdx >= 0 ? foundIdx + 1 : sortedSameDay.length + 1;

    return `${day}.${month}/${seq}`;
  }, [repair, repairs]);

  const [isPrinting, setIsPrinting] = useState(false);

  const handlePrint = async () => {
    if (!printContentRef.current || isPrinting) return;
    setIsPrinting(true);
    try {
      await printElement(printContentRef.current, {
        documentTitle: `Service_Report_${reportNumber.replace('/', '-')}`,
        pageOrientation: 'portrait',
        pageMargin: '6mm 6mm'
      });
    } catch (err) {
      console.error('Print failed:', err);
    } finally {
      setIsPrinting(false);
    }
  };

  const handlePrintInNewWindow = () => {
    if (!printContentRef.current) return;
    printInNewWindow(printContentRef.current, {
      documentTitle: `Service_Report_${reportNumber.replace('/', '-')}`,
      pageOrientation: 'portrait',
      pageMargin: '6mm 6mm'
    });
  };

  // Checkbox interactivity state
  const [urgent, setUrgent] = React.useState(false);
  const [contractType, setContractType] = React.useState<'r_plus' | 'no_contract'>('no_contract');
  const [serviceRequestBy, setServiceRequestBy] = React.useState({
    medas: false,
    itrisOffice: true,
  });
  const [requestDetail, setRequestDetail] = React.useState({
    repair: true,
    pmCal: false,
    startup: false,
    functionCheck: false,
  });

  // Diagnosis state (CSS Selectors 1 - 6)
  const [diagnosis, setDiagnosis] = React.useState({
    deviceDefect: repair?.status === 'completed',
    accessoryDefect: false,
    fallDamage: false,
    setupFailure: false,
    softwareFailure: false,
    userError: false,
  });

  // Work and Activity Performed state (CSS Selectors 7 - 14)
  const [activities, setActivities] = React.useState({
    functionCheck: true,
    checkoutConfig: true,
    deviceCleaned: true,
    accessoriesCleaned: true,
    batteryCheck: true,
    softwareCheck: false,
    displayLedCheck: true,
    printerCheck: false,
  });

  // Ready Status (CSS Selectors 15 - 16)
  const [readyStatus, setReadyStatus] = React.useState({
    deviceReady: repair?.status === 'completed',
    userTraining: false,
  });

  // Service Quality Survey (CSS Selectors 19 - 21)
  const [surveyRating, setSurveyRating] = React.useState<'good' | 'neutral' | 'poor' | null>('good');

  // Signatures footer checks (CSS Selectors 17 - 18)
  const [footerChecks, setFooterChecks] = React.useState({
    medas: false,
    invoiced: false,
  });

  // Editable Failure Description & Action Taken
  const [failureDescription, setFailureDescription] = React.useState(repair?.issue || '');
  const [actionTakenDetails, setActionTakenDetails] = React.useState(
    repair?.repairDetails || ''
  );

  React.useEffect(() => {
    if (repair) {
      setDiagnosis(prev => ({
        ...prev,
        deviceDefect: repair.status === 'completed',
      }));
      setReadyStatus(prev => ({
        ...prev,
        deviceReady: repair.status === 'completed',
      }));
      setFailureDescription(repair.issue || '');
      setActionTakenDetails(repair.repairDetails || '');
    }
  }, [repair?.id, repair?.status, repair?.issue, repair?.repairDetails]);

  if (!isOpen || !repair) return null;

  const reportDateStr = formatDateSlash(repair.reportDate || new Date().toISOString().split('T')[0]);

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden my-6 border border-slate-200 print-clean-page">
        {/* Modal Action Header (Hidden when printing) */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white print:hidden">
          <div className="flex items-center space-x-2">
            <FileText className="text-red-400" size={20} />
            <span className="font-bold text-base">แบบฟอร์มรายงานผลการซ่อม (Service Report - ITRIS Form)</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrintInNewWindow}
              type="button"
              className="flex items-center space-x-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-colors border border-slate-700 cursor-pointer"
              title="เปิดเอกสารในหน้าต่างใหม่เพื่อสั่งพิมพ์ (แนะนำหากพิมพ์โดยตรงไม่ขึ้น)"
            >
              <ExternalLink size={14} />
              <span className="hidden sm:inline">เปิดแท็บพิมพ์</span>
            </button>
            <button
              onClick={handlePrint}
              disabled={isPrinting}
              className="flex items-center space-x-1.5 px-4 py-2 bg-red-600 hover:bg-red-500 disabled:bg-red-400 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs cursor-pointer"
              title="สั่งพิมพ์ไปยังเครื่องพิมพ์ที่เชื่อมต่อกับคอมพิวเตอร์"
            >
              {isPrinting ? (
                <>
                  <Loader2 size={15} className="animate-spin" />
                  <span>กำลังส่งข้อมูลไปยังเครื่องพิมพ์...</span>
                </>
              ) : (
                <>
                  <Printer size={15} />
                  <span>พิมพ์รายงาน (Print)</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              title="ปิด"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Scrollable container for preview on screen */}
        <div className="max-h-[85vh] overflow-y-auto p-4 sm:p-8 bg-slate-100 print:bg-white print:p-0 print:overflow-visible">
          {/* Interactivity Tip Banner (Screen only) */}
          <div className="w-full max-w-[800px] mx-auto mb-3 bg-blue-50/90 border border-blue-200 rounded-xl px-4 py-2 flex items-center justify-between text-xs text-blue-900 shadow-xs print:hidden">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-blue-600">✓</span>
              <span><strong>ช่องทำเครื่องหมายถูก:</strong> สามารถคลิกที่ช่องสี่เหลี่ยมหรือข้อความเพื่อติ๊กเลือก / เอาออก (✓) ได้โดยตรงก่อนสั่งพิมพ์</span>
            </div>
          </div>

          {/* Exact Service Report Paper Document */}
          <div 
            ref={printContentRef} 
            className="w-full max-w-[800px] mx-auto bg-white text-slate-900 font-sans border border-slate-400 p-6 sm:p-8 text-[11px] leading-tight shadow-lg print:shadow-none print:border-slate-800 print:p-4"
          >
            {/* Header Section */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-400">
              {/* Logo & Company Info */}
              <div className="flex items-start space-x-2.5">
                <div className="w-9 h-9 bg-red-600 rounded flex items-center justify-center text-white font-black text-2xl leading-none shrink-0 shadow-xs">
                  +
                </div>
                <div>
                  <div className="flex items-baseline space-x-1.5">
                    <span className="text-xl font-black tracking-tighter text-red-600">iTRIS</span>
                    <span className="text-base font-bold text-slate-600 tracking-tight">MEDICAL (Thailand) Co., Ltd.</span>
                  </div>
                  <p className="text-[9px] text-slate-600 leading-tight mt-0.5">
                    218/5, 218/6 Rom Klao Rd., Kwang Klong Sam Pravet, Khet Lad Krabang, Bangkok 10520
                  </p>
                  <p className="text-[9px] text-slate-600 leading-tight">
                    Tel: 021800606 Fax: 021800605 E-Mail: info@itris-medical.co.th, web: www.itris-medical.co.th
                  </p>
                </div>
              </div>
            </div>

            {/* Title & Report No. Row */}
            <div className="grid grid-cols-12 items-center my-2.5">
              <div className="col-span-8 text-center pl-24">
                <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase -mr-[140px]">
                  Service Report
                </h1>
              </div>
              <div className="col-span-4 flex justify-end">
                <div className="border border-slate-800 rounded px-2.5 py-1 text-right min-w-[140px] bg-slate-50/50">
                  <div className="text-[9px] text-slate-500 font-semibold">Report No:</div>
                  <div className="text-xs font-mono font-bold text-slate-900">{reportNumber}</div>
                </div>
              </div>
            </div>

            {/* Main Info Section (Customer & Device Description) */}
            <div className="border-2 border-slate-800 grid grid-cols-2 divide-x-2 divide-slate-800">
              {/* Left Column: Customer Details */}
              <div className="flex flex-col justify-between">
                <div className="p-2 border-b border-slate-800">
                  <div className="font-bold text-slate-900 text-xs mb-1">Customer</div>
                  <div className="space-y-1 text-[10px]">
                    <div className="flex">
                      <span className="w-16 font-semibold text-slate-700">Name</span>
                      <span className="font-medium text-slate-900 flex-1">{displayDepartment || 'โรงพยาบาล / หน่วยงานบริการ'}</span>
                    </div>
                    <div className="flex">
                      <span className="w-16 font-semibold text-slate-700">Address</span>
                      <span className="text-slate-800 flex-1">กรุงเทพมหานคร / Thailand</span>
                    </div>
                  </div>
                </div>

                <div className="p-1.5 border-b border-slate-800 flex items-center justify-between text-[10px]">
                  <div 
                    onClick={() => isAdmin && setUrgent(!urgent)}
                    className={`flex items-center space-x-1.5 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                    title={isAdmin ? "คลิกเพื่อติ๊กเลือก/ยกเลิก" : undefined}
                  >
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {urgent ? '✓' : ''}
                    </span>
                    <span className="font-medium">Urgent</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="font-medium text-slate-700">Date:</span>
                    <span className="font-mono underline min-w-[4.5rem] inline-block text-center">{urgent ? reportDateStr : ''}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="font-medium text-slate-700">Time:</span>
                    <span className="font-mono underline min-w-[3rem] inline-block text-center">{urgent ? (repair.reportTime || '09:00') : ''}</span>
                  </div>
                </div>

                <div className="p-2 border-b border-slate-800">
                  <div className="flex text-[10px]">
                    <span className="font-bold text-slate-800 mr-2">Department:</span>
                    <span className="font-medium text-slate-900">{displayDepartment}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 divide-x border-slate-800 text-[10px]">
                  <div className="p-1.5">
                    <span className="block font-semibold text-slate-700 text-[9px] mb-0.5">Customer / user name:</span>
                    {repair.requesterSignature ? (
                      <div className="flex flex-col mt-1">
                        <img src={repair.requesterSignature} className="h-7 w-auto max-w-[100px] object-contain object-left mt-0 mr-[2px] mb-[2px] ml-[31px]" alt="signature" />
                        <span className="font-bold text-slate-900 text-[10px] leading-tight ml-[57px]">
                          {repair.signerName || repair.reportedBy || '-'}
                        </span>
                      </div>
                    ) : (
                      <span className="font-bold text-slate-900 block">{repair.signerName || repair.reportedBy || '-'}</span>
                    )}
                  </div>
                  <div className="p-1.5">
                    <span className="block font-semibold text-slate-700 text-[9px] mb-0.5">ITRIS engineer name:</span>
                    {repair.technicianSignature ? (
                      <div className="flex flex-col mt-1">
                        <img 
                          src={repair.technicianSignature} 
                          className="h-7 w-auto max-w-[100px] object-contain object-left mb-0.5 ml-[37px]" 
                          alt="ITRIS technician signature" 
                        />
                        <span className="font-bold text-slate-900 text-[10px] leading-tight ml-[52px]">
                          {repair.technician || '-'}
                        </span>
                      </div>
                    ) : repair.closingTechnicianSignature ? (
                      <div className="flex flex-col mt-1">
                        <img 
                          src={repair.closingTechnicianSignature} 
                          className="h-7 w-auto max-w-[100px] object-contain object-left mb-0.5 ml-[37px]" 
                          alt="ITRIS closing technician signature" 
                        />
                        <span className="font-bold text-slate-900 text-[10px] leading-tight ml-[52px]">
                          {repair.closingTechnician || repair.technician || '-'}
                        </span>
                      </div>
                    ) : (
                      <span className="font-bold text-slate-900 block mt-0.5">
                        {repair.technician || repair.closingTechnician || '-'}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Device Description */}
              <div className="text-[10px] flex flex-col justify-between">
                <div className="p-2 border-b border-slate-800">
                  <span className="font-bold text-slate-900 text-xs block mb-0.5">Device description:</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-slate-900 block">
                      {displayName || 'ไม่ระบุชื่อเครื่องมือ'}
                    </span>
                    {isNonRegistered && (
                      <span className="text-[9px] px-1.5 py-0.2 bg-amber-50 text-amber-800 border border-amber-300 rounded font-medium print:hidden">
                        นอกทะเบียน
                      </span>
                    )}
                  </div>
                </div>
                <div className="p-1.5 border-b border-slate-800 flex">
                  <span className="w-24 font-semibold text-slate-700">ID no.:</span>
                  <span className="font-bold font-mono text-slate-900">{displayCode}</span>
                </div>
                <div className="p-1.5 border-b border-slate-800 flex">
                  <span className="w-24 font-semibold text-slate-700">Serial no.:</span>
                  <span className="font-mono text-slate-900">{displaySerial}</span>
                </div>
                <div className="p-1.5 border-b border-slate-800 flex">
                  <span className="w-24 font-semibold text-slate-700">Model / Type:</span>
                  <span className="text-slate-900">{displayModel}</span>
                </div>
                <div className="p-1.5 border-b border-slate-800 flex">
                  <span className="w-24 font-semibold text-slate-700">Manufacturer:</span>
                  <span className="text-slate-900">{displayManufacturer}</span>
                </div>
                <div className="p-1.5 flex">
                  <span className="w-24 font-semibold text-slate-700">Contract no.:</span>
                  <span className="text-slate-900 font-mono">-</span>
                </div>
              </div>
            </div>

            {/* Service Request By & Request Detail */}
            <div className="border-x-2 border-b-2 border-slate-800 text-[10px]">
              <div className="p-1.5 border-b border-slate-800 grid grid-cols-12 gap-2 items-center">
                <div className="col-span-6 flex items-center space-x-3">
                  <span className="font-bold text-slate-900">Service request by:</span>
                  <label 
                    onClick={() => isAdmin && setServiceRequestBy(prev => ({ ...prev, medas: !prev.medas }))}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {serviceRequestBy.medas ? '✓' : ''}
                    </span>
                    <span>MEDAS</span>
                  </label>
                  <label 
                    onClick={() => isAdmin && setServiceRequestBy(prev => ({ ...prev, itrisOffice: !prev.itrisOffice }))}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {serviceRequestBy.itrisOffice ? '✓' : ''}
                    </span>
                    <span>To ITRIS office</span>
                  </label>
                </div>
                <div className="col-span-6 flex items-center space-x-3 justify-end">
                  <span className="font-bold text-slate-900">Contract:</span>
                  <label 
                    onClick={() => isAdmin && setContractType(contractType === 'r_plus' ? 'no_contract' : 'r_plus')}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {contractType === 'r_plus' ? '✓' : ''}
                    </span>
                    <span>R+ Contract</span>
                  </label>
                  <label 
                    onClick={() => isAdmin && setContractType(contractType === 'no_contract' ? 'r_plus' : 'no_contract')}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {contractType === 'no_contract' ? '✓' : ''}
                    </span>
                    <span>No Contract</span>
                  </label>
                </div>
              </div>

              <div className="p-1.5 border-b border-slate-800 flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="font-bold text-slate-900">Request detail:</span>
                <label 
                  onClick={() => isAdmin && setRequestDetail(prev => ({ ...prev, repair: !prev.repair }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {requestDetail.repair ? '✓' : ''}
                  </span>
                  <span>Repair</span>
                </label>
                <label 
                  onClick={() => isAdmin && setRequestDetail(prev => ({ ...prev, pmCal: !prev.pmCal }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {requestDetail.pmCal ? '✓' : ''}
                  </span>
                  <span>PM/CAL</span>
                </label>
                <label 
                  onClick={() => isAdmin && setRequestDetail(prev => ({ ...prev, startup: !prev.startup }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {requestDetail.startup ? '✓' : ''}
                  </span>
                  <span>New device initial start-up</span>
                </label>
                <label 
                  onClick={() => isAdmin && setRequestDetail(prev => ({ ...prev, functionCheck: !prev.functionCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {requestDetail.functionCheck ? '✓' : ''}
                  </span>
                  <span>Device function check</span>
                </label>
              </div>

              {/* Failure Description */}
              <div className="p-2">
                <span className="font-bold text-slate-900 block mb-1">Failure description:</span>
                <textarea
                  value={failureDescription}
                  onChange={(e) => isAdmin && setFailureDescription(e.target.value)}
                  readOnly={!isAdmin}
                  placeholder={isAdmin ? "ระบุอาการเสีย หรือรายละเอียด..." : ""}
                  rows={2}
                  className={`w-full min-h-[38px] p-1.5 rounded border text-slate-800 font-medium text-[9.5px] leading-relaxed transition-colors print:border-none print:bg-transparent print:p-0 print:resize-none ${
                    isAdmin 
                      ? "bg-slate-50/70 hover:bg-slate-50 focus:bg-white border-slate-200 focus:border-blue-500 focus:outline-none resize-y" 
                      : "bg-transparent border-slate-200 cursor-default resize-none focus:outline-none"
                  }`}
                />
              </div>
            </div>

            {/* Diagnosis Section */}
            <div className="border-x-2 border-b-2 border-slate-800 p-2 text-[10px]">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="font-bold text-slate-900">Diagnosis:</span>
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, deviceDefect: !prev.deviceDefect }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.deviceDefect ? '✓' : ''}
                  </span>
                  <span>Device defect</span>
                </label>
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, accessoryDefect: !prev.accessoryDefect }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.accessoryDefect ? '✓' : ''}
                  </span>
                  <span>Accessory defect</span>
                </label>
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, fallDamage: !prev.fallDamage }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.fallDamage ? '✓' : ''}
                  </span>
                  <span>Fall damage</span>
                </label>
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, setupFailure: !prev.setupFailure }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.setupFailure ? '✓' : ''}
                  </span>
                  <span>Set-up failure</span>
                </label>
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, softwareFailure: !prev.softwareFailure }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.softwareFailure ? '✓' : ''}
                  </span>
                  <span>Application or Software failure</span>
                </label>
              </div>
              <div className="mt-1 pl-16 -ml-[4px]">
                <label 
                  onClick={() => isAdmin && setDiagnosis(prev => ({ ...prev, userError: !prev.userError }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {diagnosis.userError ? '✓' : ''}
                  </span>
                  <span>User Error</span>
                </label>
              </div>
            </div>

            {/* Engineer Timesheet Table */}
            <div className="border-x-2 border-b-2 border-slate-800">
              <table className="w-full text-[9.5px] border-collapse text-center">
                <thead>
                  <tr className="border-b border-slate-800 font-bold text-slate-800 bg-slate-50">
                    <th className="border-r border-slate-800 p-1 w-20">Date</th>
                    <th className="border-r border-slate-800 p-1">Engineer name</th>
                    <th className="border-r border-slate-800 p-1 w-16">Start time</th>
                    <th className="border-r border-slate-800 p-1 w-16">End time</th>
                    <th className="border-r border-slate-800 p-1 w-24">Total labour time</th>
                    <th className="border-r border-slate-800 p-1 w-20">Travel time</th>
                    <th className="p-1 w-20">Total time</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-400">
                    <td className="border-r border-slate-800 p-1 font-mono">{reportDateStr}</td>
                    <td className="border-r border-slate-800 p-1 font-medium">{repair.technician || '-'}</td>
                    <td className="border-r border-slate-800 p-1 font-mono">{repair.reportTime || '09:00'}</td>
                    <td className="border-r border-slate-800 p-1 font-mono">{repair.closingTime || (repair.status === 'completed' ? '12:00' : '-')}</td>
                    <td className="border-r border-slate-800 p-1 font-mono">3.0 hrs</td>
                    <td className="border-r border-slate-800 p-1 font-mono">1.0 hr</td>
                    <td className="p-1 font-mono font-bold">4.0 hrs</td>
                  </tr>
                  <tr className="border-b border-slate-400">
                    <td className="border-r border-slate-800 p-1 h-5"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="p-1"></td>
                  </tr>
                  <tr>
                    <td className="border-r border-slate-800 p-1 h-5"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="p-1"></td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Work and Activity Performed */}
            <div className="border-x-2 border-b-2 border-slate-800 p-2 text-[10px]">
              <span className="font-bold text-slate-900 block mb-1">Work and activity performed:</span>
              
              {/* Checkboxes grid */}
              <div className="grid grid-cols-4 gap-y-1 gap-x-2 text-[9px] mb-2">
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, functionCheck: !prev.functionCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.functionCheck ? '✓' : ''}
                  </span>
                  <span>Function check</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, checkoutConfig: !prev.checkoutConfig }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.checkoutConfig ? '✓' : ''}
                  </span>
                  <span>Checkout device configuration</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, deviceCleaned: !prev.deviceCleaned }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.deviceCleaned ? '✓' : ''}
                  </span>
                  <span>Device cleaned</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, accessoriesCleaned: !prev.accessoriesCleaned }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.accessoriesCleaned ? '✓' : ''}
                  </span>
                  <span>Accessories cleaned</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, batteryCheck: !prev.batteryCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.batteryCheck ? '✓' : ''}
                  </span>
                  <span>Battery check</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, softwareCheck: !prev.softwareCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.softwareCheck ? '✓' : ''}
                  </span>
                  <span>Application/Software check</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, displayLedCheck: !prev.displayLedCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.displayLedCheck ? '✓' : ''}
                  </span>
                  <span>Display/LED check</span>
                </label>
                <label 
                  onClick={() => isAdmin && setActivities(prev => ({ ...prev, printerCheck: !prev.printerCheck }))}
                  className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {activities.printerCheck ? '✓' : ''}
                  </span>
                  <span>Printer check/test print</span>
                </label>
              </div>

              {/* Action taken / Work details table */}
              <div className="mt-2 pt-1.5 border-t border-slate-300">
                <div className="w-full border border-slate-300 rounded overflow-hidden">
                  <div className="bg-slate-50 px-2 py-1 font-bold text-slate-800 text-[9.5px] border-b border-slate-300 flex justify-between items-center">
                    <span>Action taken / รายละเอียดการซ่อมและบำรุงรักษา:</span>
                    {isAdmin && (
                      <span className="text-[8.5px] text-slate-400 font-normal print:hidden">(สามารถพิมพ์แก้ไขได้)</span>
                    )}
                  </div>
                  <textarea
                    value={actionTakenDetails}
                    onChange={(e) => isAdmin && setActionTakenDetails(e.target.value)}
                    readOnly={!isAdmin}
                    placeholder={isAdmin ? "ระบุรายละเอียดขั้นตอนการดำเนินการ หรือการซ่อมบำรุง..." : ""}
                    rows={2}
                    className={`w-full min-h-[38px] p-1.5 text-slate-800 text-[9.5px] font-medium leading-relaxed print:p-0 print:resize-none ${
                      isAdmin
                        ? "bg-white hover:bg-slate-50/40 focus:bg-white border-0 focus:ring-1 focus:ring-blue-500 focus:outline-none resize-y"
                        : "bg-white border-0 cursor-default resize-none focus:outline-none"
                    }`}
                  />
                </div>
              </div>

              {/* Ready status checkboxes */}
              <div className="flex items-center space-x-6 mt-2 pt-1.5 border-t border-slate-200 text-[10px]">
                <label 
                  onClick={() => isAdmin && setReadyStatus(prev => ({ ...prev, deviceReady: !prev.deviceReady }))}
                  className={`flex items-center space-x-1.5 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {readyStatus.deviceReady ? '✓' : ''}
                  </span>
                  <span className="font-bold text-slate-900">Device tested and ready for use</span>
                </label>
                <label 
                  onClick={() => isAdmin && setReadyStatus(prev => ({ ...prev, userTraining: !prev.userTraining }))}
                  className={`flex items-center space-x-1.5 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                >
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                    {readyStatus.userTraining ? '✓' : ''}
                  </span>
                  <span>User training executed</span>
                </label>
              </div>
            </div>

            {/* Spare Parts Table */}
            <div className="border-x-2 border-b-2 border-slate-800">
              <div className="p-1.5 bg-slate-50 border-b border-slate-800 font-bold text-[10px] text-slate-900">
                Spare parts for repair, consumable materials for the maintenance:
              </div>
              <table className="w-full text-[9.5px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 font-semibold text-slate-800">
                    <th className="border-r border-slate-800 p-1 w-32">Article no./ Order no.</th>
                    <th className="border-r border-slate-800 p-1 w-12 text-center">Qty.</th>
                    <th className="border-r border-slate-800 p-1">Description</th>
                    <th className="border-r border-slate-800 p-1 w-28">Serial-no. device</th>
                    <th className="p-1 w-28">Supplier</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-300">
                    <td className="border-r border-slate-800 p-1 h-5"></td>
                    <td className="border-r border-slate-800 p-1 text-center"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="p-1"></td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="border-r border-slate-800 p-1 h-5"></td>
                    <td className="border-r border-slate-800 p-1 text-center"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="p-1"></td>
                  </tr>
                  <tr>
                    <td className="border-r border-slate-800 p-1 h-5"></td>
                    <td className="border-r border-slate-800 p-1 text-center"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="border-r border-slate-800 p-1"></td>
                    <td className="p-1"></td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Service Quality Survey */}
            <div className="border-x-2 border-b-2 border-slate-800 p-1.5 flex items-center justify-end space-x-6 text-[10px]">
              <span className="font-bold text-slate-800">Service Quality Survey:</span>
              <div 
                onClick={() => isAdmin && setSurveyRating(surveyRating === 'good' ? null : 'good')}
                className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
              >
                <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                  {surveyRating === 'good' ? '✓' : ''}
                </span>
                <span className="text-sm">😊</span>
              </div>
              <div 
                onClick={() => isAdmin && setSurveyRating(surveyRating === 'neutral' ? null : 'neutral')}
                className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
              >
                <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                  {surveyRating === 'neutral' ? '✓' : ''}
                </span>
                <span className="text-sm">😐</span>
              </div>
              <div 
                onClick={() => isAdmin && setSurveyRating(surveyRating === 'poor' ? null : 'poor')}
                className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
              >
                <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                  {surveyRating === 'poor' ? '✓' : ''}
                </span>
                <span className="text-sm">☹️</span>
              </div>
            </div>

            {/* Signatures Footer Grid */}
            <div className="border-x-2 border-b-2 border-slate-800 grid grid-cols-12 divide-x-2 divide-slate-800 text-[10px]">
              {/* Left: MEDAS & Invoice */}
              <div className="col-span-4 p-2 flex flex-col justify-between space-y-2">
                <div className="flex items-center justify-between">
                  <div 
                    onClick={() => isAdmin && setFooterChecks(prev => ({ ...prev, medas: !prev.medas }))}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="font-semibold text-slate-800">Admitted in MEDAS:</span>
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {footerChecks.medas ? '✓' : ''}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between pb-[15px]">
                  <div 
                    onClick={() => isAdmin && setFooterChecks(prev => ({ ...prev, invoiced: !prev.invoiced }))}
                    className={`flex items-center space-x-1 select-none ${isAdmin ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    <span className="font-semibold text-slate-800">Invoiced:</span>
                    <span className="inline-flex items-center justify-center w-3.5 h-3.5 border border-slate-800 text-center text-[9px] font-bold bg-white">
                      {footerChecks.invoiced ? '✓' : ''}
                    </span>
                  </div>
                  <div className="flex items-end">
                    <span className="text-slate-600 mr-1 mb-0.5">Date:</span>
                    <div className="border-b border-slate-400 min-w-[6rem] text-center font-mono">
                      {reportDateStr}
                    </div>
                  </div>
                </div>
              </div>

              {/* Center: ITRIS signature (เฉพาะช่างผู้ดำเนินการซ่อม) */}
              <div className="col-span-4 p-2 flex flex-col justify-between">
                <div className="font-bold text-slate-900 mb-1 flex items-center justify-between">
                  <span>ITRIS signature:</span>
                </div>
                <div className="h-12 flex items-center justify-center">
                  {repair.closingTechnicianSignature ? (
                    <img
                      src={repair.closingTechnicianSignature}
                      alt="ลายเซ็นช่างผู้ดำเนินการซ่อม"
                      className="max-h-11 max-w-[140px] object-contain"
                    />
                  ) : repair.closingTechnician ? (
                    <div className="text-sm font-bold text-slate-800 italic font-mono">
                      {repair.closingTechnician}
                    </div>
                  ) : null}
                </div>
                <div className="text-center font-semibold text-slate-800 border-t border-slate-300 pt-1 text-[9px]">
                  ({repair.closingTechnician || 'ช่างผู้ดำเนินการซ่อม'})
                </div>
              </div>

              {/* Right: Customer signature */}
              <div className="col-span-4 p-2 flex flex-col justify-between">
                <div className="font-bold text-slate-900 mt-[20px] pb-[6px] -mb-[12px]">Customer signature:</div>
                <div className="h-12 flex items-center justify-center">
                  {repair.closingSignature ? (
                    <img
                      src={repair.closingSignature}
                      alt="Customer Signature"
                      className="max-h-11 max-w-[140px] object-contain"
                    />
                  ) : (repair.closingSignerName || repair.closerName) ? (
                    <div className="text-sm font-bold text-slate-800 italic">
                      {repair.closingSignerName || repair.closerName}
                    </div>
                  ) : null}
                </div>
                <div className="text-center font-semibold text-slate-800 border-t border-slate-300 pt-1 text-[9px]">
                  {(repair.closingSignature || repair.closingSignerName || repair.closerName) ? (
                    `(${repair.closingSignerName || repair.closerName || 'Customer Signature'})`
                  ) : (
                    '(............................................)'
                  )}
                </div>
              </div>
            </div>

            {/* Document Bottom Footer */}
            <div className="flex items-center justify-between pt-2 text-[8px] text-slate-500 font-medium">
              <div>FP-OP-002-001 Rev.03</div>
              <div>ITRIS Medical (Thailand) Co., Ltd. terms & conditions are applicable</div>
            </div>
          </div>
        </div>

        {/* Modal Footer (Hidden when printing) */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end space-x-2 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            ปิดหน้าต่าง
          </button>
          <button
            type="button"
            onClick={handlePrintInNewWindow}
            className="flex items-center space-x-1.5 px-3.5 py-2 border border-slate-300 text-slate-700 bg-white hover:bg-slate-100 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            title="เปิดเอกสารในหน้าต่างใหม่เพื่อสั่งพิมพ์ (กรณีพิมพ์โดยตรงไม่ตอบสนอง)"
          >
            <ExternalLink size={14} />
            <span>เปิดหน้าต่างพิมพ์</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            disabled={isPrinting}
            className="flex items-center space-x-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs cursor-pointer"
            title="สั่งพิมพ์ไปยังเครื่องพิมพ์ที่เชื่อมต่อกับคอมพิวเตอร์"
          >
            {isPrinting ? (
              <>
                <Loader2 size={15} className="animate-spin" />
                <span>กำลังส่งข้อมูลไปยังเครื่องพิมพ์...</span>
              </>
            ) : (
              <>
                <Printer size={15} />
                <span>พิมพ์รายงาน (Print)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

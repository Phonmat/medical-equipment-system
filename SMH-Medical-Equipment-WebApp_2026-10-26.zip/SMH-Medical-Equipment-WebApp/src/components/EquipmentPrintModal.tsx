import React, { useRef, useState, useEffect } from 'react';
import { 
  Printer, X, Loader2, ArrowDownRight, 
  ClipboardCheck, ArrowLeft, Tag, CheckCircle2,
  PenLine, RotateCcw, Trash2, Check
} from 'lucide-react';
import { Equipment } from '../types';
import { useAppStore } from '../store';
import { 
  formatDateSlash, formatPurchasePrice, formatWarrantyDisplay, 
  formatWarrantyDateRange 
} from '../utils/dateUtils';
import { printElement } from '../utils/printUtils';

interface EquipmentPrintModalProps {
  equipment: Equipment | null;
  equipmentList?: Equipment[];
  isOpen: boolean;
  onClose: () => void;
  initialDocType?: 'mutation_in' | 'inspection' | null;
}

interface SavedSignature {
  signature: string;
  name?: string;
  date?: string;
}

interface SignaturePadModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  defaultName: string;
  defaultDate: string;
  onSave: (data: { signature: string; name: string; date: string }) => void;
}

function SignaturePadModal({
  isOpen,
  onClose,
  title,
  defaultName,
  defaultDate,
  onSave,
}: SignaturePadModalProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [penColor, setPenColor] = useState<string>('#1e3a8a');
  const [name, setName] = useState(defaultName);
  const [date, setDate] = useState(defaultDate);

  useEffect(() => {
    if (isOpen) {
      setName(defaultName);
      setDate(defaultDate);
      setHasDrawn(false);
      setIsDrawing(false);
      setTimeout(() => {
        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
          }
        }
      }, 60);
    }
  }, [isOpen, defaultName, defaultDate]);

  if (!isOpen) return null;

  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      if (e.touches.length === 0) return { x: 0, y: 0 };
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if ('touches' in e) {
      e.stopPropagation();
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const { x, y } = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = penColor;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    if ('touches' in e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
    setHasDrawn(true);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas || !hasDrawn) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSave({ signature: dataUrl, name: name.trim(), date });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <PenLine size={18} className="text-blue-400" />
            <h3 className="font-bold text-sm sm:text-base">เซ็นลายเซ็น: {title}</h3>
          </div>
          <button 
            type="button" 
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {/* Controls Bar above canvas */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-500 font-medium">สีหมึก:</span>
              <button
                type="button"
                onClick={() => setPenColor('#1e3a8a')}
                className={`w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                  penColor === '#1e3a8a' ? 'border-blue-600 scale-110 shadow-xs' : 'border-slate-300'
                }`}
                style={{ backgroundColor: '#1e3a8a' }}
                title="น้ำเงินทางการ"
              >
                {penColor === '#1e3a8a' && <Check size={12} className="text-white" />}
              </button>
              <button
                type="button"
                onClick={() => setPenColor('#0f172a')}
                className={`w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                  penColor === '#0f172a' ? 'border-blue-600 scale-110 shadow-xs' : 'border-slate-300'
                }`}
                style={{ backgroundColor: '#0f172a' }}
                title="ดำมาตรฐาน"
              >
                {penColor === '#0f172a' && <Check size={12} className="text-white" />}
              </button>
            </div>

            <button
              type="button"
              onClick={clearCanvas}
              className="inline-flex items-center space-x-1 text-xs text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg border border-rose-200 transition-colors font-medium cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>ล้างกระดาน</span>
            </button>
          </div>

          {/* Canvas Box */}
          <div className="relative border-2 border-dashed border-slate-300 rounded-xl overflow-hidden bg-slate-50/50 flex flex-col items-center">
            <canvas
              ref={canvasRef}
              width={480}
              height={180}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="w-full h-[180px] bg-white cursor-crosshair touch-none"
            />
            {!hasDrawn && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-slate-400">
                <PenLine size={24} className="mb-1 text-slate-300" />
                <span className="text-xs">ลากเมาส์หรือใช้นิ้วสัมผัสเพื่อเซ็นชื่อที่นี่</span>
              </div>
            )}
            <div className="w-full border-t border-slate-100 bg-slate-50 px-3 py-1 text-[10px] text-slate-400 text-center">
              ลายเซ็นอิเล็กทรอนิกส์สำหรับเอกสารควบคุมเครื่องมือแพทย์
            </div>
          </div>

          {/* Signer Info inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                ชื่อ-นามสกุล / ตำแหน่งผู้ลงนาม
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="ระบุชื่อผู้ลงนาม..."
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                วันที่ลงนาม
              </label>
              <input
                type="text"
                value={date}
                onChange={e => setDate(e.target.value)}
                placeholder="วว/ดด/ปปปป"
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            ยกเลิก
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!hasDrawn}
            className="inline-flex items-center space-x-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 disabled:cursor-not-allowed rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            <Check size={14} />
            <span>บันทึกลายเซ็น</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// Reusable Circular Radio (Exact Match to PDF)
const RadioCircle = ({ 
  checked, 
  label, 
  onClick,
  className = '' 
}: { 
  checked?: boolean; 
  label: string; 
  onClick?: () => void;
  className?: string 
}) => (
  <span 
    onClick={onClick}
    className={`inline-flex items-center space-x-1 mr-2 text-[9px] leading-none select-none ${onClick ? 'cursor-pointer hover:opacity-75' : ''} ${className}`}
  >
    <span className="w-2.5 h-2.5 rounded-full border border-black flex items-center justify-center shrink-0 bg-white">
      {checked && <span className="w-1.5 h-1.5 rounded-full bg-black"></span>}
    </span>
    <span className="whitespace-nowrap">{label}</span>
  </span>
);

// Reusable Square Checkbox (Exact Match to PDF)
const CheckSquare = ({ 
  checked, 
  label, 
  onClick,
  className = '' 
}: { 
  checked?: boolean; 
  label: string; 
  onClick?: () => void;
  className?: string 
}) => (
  <span 
    onClick={onClick}
    className={`inline-flex items-center space-x-1.5 mr-3 text-[9px] leading-none select-none ${onClick ? 'cursor-pointer hover:opacity-75' : ''} ${className}`}
  >
    <span className="w-3 h-3 border border-black flex items-center justify-center shrink-0 bg-white">
      {checked && <span className="text-[10px] font-black leading-none text-black">✓</span>}
    </span>
    <span className="whitespace-nowrap font-medium">{label}</span>
  </span>
);

export default function EquipmentPrintModal({
  equipment,
  equipmentList,
  isOpen,
  onClose,
  initialDocType = null,
}: EquipmentPrintModalProps) {
  const { currentUser } = useAppStore();
  const printContentRef = useRef<HTMLDivElement>(null);
  const [docType, setDocType] = useState<'mutation_in' | 'inspection' | null>(initialDocType);
  const [isPrinting, setIsPrinting] = useState(false);
  const [ownership, setOwnership] = useState<'hospital' | 'leased' | 'profit_sharing' | 'other'>('hospital');
  const [otherOwnershipText, setOtherOwnershipText] = useState('');
  const [riskLevelChoice, setRiskLevelChoice] = useState<'HIGH' | 'MEDUIM' | 'LOW'>('LOW');
  const [clinicalAlarmChoice, setClinicalAlarmChoice] = useState<'YES' | 'NO' | 'UNKNOWN'>('NO');
  const [classificationChoice, setClassificationChoice] = useState<string>('DIAGNOSTIC');
  const [commentLine1, setCommentLine1] = useState('');
  const [commentLine2, setCommentLine2] = useState('');
  const [signatures, setSignatures] = useState<Record<string, SavedSignature>>({});
  const [signingModal, setSigningModal] = useState<{
    key: string;
    title: string;
    defaultName: string;
    defaultDate: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setDocType(initialDocType || null);
      setOwnership('hospital');
      setOtherOwnershipText('');
      setCommentLine1('');
      setCommentLine2('');

      const risk = (equipment?.riskLevel || 'Low').toLowerCase();
      if (risk.includes('high') || risk.includes('critical')) {
        setRiskLevelChoice('HIGH');
      } else if (risk.includes('medium') || risk.includes('moderate') || risk.includes('meduim')) {
        setRiskLevelChoice('MEDUIM');
      } else {
        setRiskLevelChoice('LOW');
      }

      const nameLower = (equipment?.name || '').toLowerCase();
      const isHigh = risk.includes('high') || risk.includes('critical');
      const isLifeSup = isHigh || nameLower.includes('ventilator') || nameLower.includes('defib') || nameLower.includes('anesthesia');
      const isDiag = !isLifeSup && (nameLower.includes('monitor') || nameLower.includes('ecg') || nameLower.includes('x-ray') || nameLower.includes('ultra') || nameLower.includes('scop'));
      const isCrit = !isLifeSup && !isDiag && nameLower.includes('monitor');
      const isTherap = !isLifeSup && !isDiag && (nameLower.includes('pump') || nameLower.includes('cautery') || nameLower.includes('laser'));
      const isEnergy = nameLower.includes('laser') || nameLower.includes('x-ray') || nameLower.includes('radio');

      if (isLifeSup) setClassificationChoice('LIFE SUPPORT OR RESC');
      else if (isDiag) setClassificationChoice('DIAGNOSTIC');
      else if (isCrit) setClassificationChoice('CRITICAL MONITORING');
      else if (isEnergy) setClassificationChoice('ENERGY-EMITTING');
      else if (isTherap) setClassificationChoice('THERAPEUTIC');
      else setClassificationChoice('MISC OTHER');

      setClinicalAlarmChoice((isHigh || isLifeSup || isDiag) ? 'YES' : 'NO');
    }
  }, [isOpen, equipment?.id, equipment?.name, equipment?.riskLevel, initialDocType]);

  const today = new Date();
  const nextInspectionDate = new Date(today);
  nextInspectionDate.setFullYear(today.getFullYear() + 1);
  const formattedToday = formatDateSlash(today.toISOString().split('T')[0]);
  const formattedNextInspection = formatDateSlash(nextInspectionDate.toISOString().split('T')[0]);

  // Load signatures from localStorage
  useEffect(() => {
    if (equipment && docType) {
      const storageKey = `eq_doc_sig_${equipment.id}_${docType}`;
      try {
        const saved = localStorage.getItem(storageKey);
        if (saved) {
          setSignatures(JSON.parse(saved));
        } else {
          setSignatures({});
        }
      } catch (e) {
        setSignatures({});
      }
    }
  }, [equipment?.id, docType]);

  const handleOpenSigning = (key: string, title: string, defaultName: string) => {
    const existing = signatures[key];
    setSigningModal({
      key,
      title,
      defaultName: existing?.name || defaultName || '',
      defaultDate: existing?.date || formattedToday || '',
    });
  };

  const handleSaveSignature = (data: { signature: string; name: string; date: string }) => {
    if (!signingModal || !equipment || !docType) return;
    const { key } = signingModal;
    const storageKey = `eq_doc_sig_${equipment.id}_${docType}`;
    setSignatures(prev => {
      const updated = { ...prev, [key]: data };
      try {
        localStorage.setItem(storageKey, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const handleRemoveSignature = (key: string) => {
    if (!equipment || !docType) return;
    const storageKey = `eq_doc_sig_${equipment.id}_${docType}`;
    setSignatures(prev => {
      const updated = { ...prev };
      delete updated[key];
      try {
        localStorage.setItem(storageKey, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  if (!isOpen) return null;

  const isListView = !equipment && equipmentList && equipmentList.length > 0;

  const warrantyRange = equipment ? formatWarrantyDateRange(equipment) : null;
  const warrantyExpiration = warrantyRange?.end || (equipment?.warrantyPeriod ? formatDateSlash(equipment.warrantyPeriod) : '');

  // Derived classification & risks for the selected device
  const risk = (equipment?.riskLevel || 'Low').toLowerCase();
  const isHighRisk = risk.includes('high') || risk.includes('critical');
  const isMedRisk = risk.includes('medium') || risk.includes('moderate');
  const isLowRisk = !isHighRisk && !isMedRisk;

  const nameLower = (equipment?.name || '').toLowerCase();
  const isLifeSupport = isHighRisk || nameLower.includes('ventilator') || nameLower.includes('defib') || nameLower.includes('anesthesia');
  const isDiagnostic = !isLifeSupport && (nameLower.includes('monitor') || nameLower.includes('ecg') || nameLower.includes('x-ray') || nameLower.includes('ultra') || nameLower.includes('scop'));
  const isCriticalMonitoring = !isLifeSupport && !isDiagnostic && nameLower.includes('monitor');
  const isTherapeutic = !isLifeSupport && !isDiagnostic && (nameLower.includes('pump') || nameLower.includes('cautery') || nameLower.includes('laser'));
  const isEnergyEmitting = nameLower.includes('laser') || nameLower.includes('x-ray') || nameLower.includes('radio');
  const isMiscOther = !isLifeSupport && !isDiagnostic && !isCriticalMonitoring && !isTherapeutic && !isEnergyEmitting;

  const hasClinicalAlarm = isHighRisk || isLifeSupport || isDiagnostic;

  const docTitle = isListView
    ? `Equipment_Register_List_${today.toISOString().split('T')[0]}`
    : docType === 'mutation_in'
    ? `Mutation_IN_${equipment?.code || 'Device'}`
    : docType === 'inspection'
    ? `Inspection_Report_${equipment?.code || 'Device'}`
    : `Equipment_${equipment?.code || 'Device'}`;

  const handlePrint = async () => {
    if (!printContentRef.current || isPrinting) return;
    setIsPrinting(true);
    try {
      await printElement(printContentRef.current, {
        documentTitle: docTitle,
        pageOrientation: isListView ? 'landscape' : 'portrait',
        pageMargin: '4mm 4mm'
      });
    } catch (err) {
      console.error('Print failed:', err);
    } finally {
      setIsPrinting(false);
    }
  };

  // =========================================================================
  // 1. หน้าต่างเล็กๆ ให้เลือกเอกสาร (Small Choice Popup Dialog)
  // =========================================================================
  if (equipment && docType === null) {
    return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
        <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200 animate-scale-up">
          {/* Header */}
          <div className="bg-slate-900 text-white px-5 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 bg-blue-600/30 text-blue-400 rounded-xl border border-blue-500/30">
                <Printer size={18} />
              </div>
              <div>
                <h3 className="font-bold text-sm">พิมพ์เอกสารเครื่องมือแพทย์</h3>
                <p className="text-xs text-slate-400">เลือกประเภทเอกสารที่ต้องการพิมพ์</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="ปิดหน้าต่าง"
            >
              <X size={18} />
            </button>
          </div>

          {/* Current Selected Equipment Badge */}
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <div className="text-[11px] text-slate-500 font-medium mb-1.5 flex items-center space-x-1">
              <Tag size={12} className="text-slate-400" />
              <span>เครื่องมือแพทย์ที่เลือก:</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="font-mono font-bold text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded border border-blue-200 shrink-0">
                {equipment.code}
              </span>
              <span className="text-xs font-semibold text-slate-800 truncate" title={equipment.name}>
                {equipment.name}
              </span>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-slate-200/80">
              <div className="truncate">
                <span className="text-slate-400">แผนก: </span>
                <strong className="text-slate-700 font-medium">{equipment.department || '-'}</strong>
              </div>
              <div className="truncate">
                <span className="text-slate-400">S/N: </span>
                <strong className="text-slate-700 font-mono font-medium">{equipment.serialNumber || '-'}</strong>
              </div>
              <div className="truncate">
                <span className="text-slate-400">รุ่น: </span>
                <span className="text-slate-700 font-medium">{equipment.model || '-'}</span>
              </div>
              <div className="truncate">
                <span className="text-slate-400">Itris ID: </span>
                <span className="text-slate-700 font-mono">{equipment.itrisId || '-'}</span>
              </div>
            </div>
          </div>

          {/* Document Selection Buttons */}
          <div className="p-4 space-y-3">
            {/* Option 1: เอกสาร Mutation IN */}
            <button
              type="button"
              onClick={() => setDocType('mutation_in')}
              className="w-full text-left p-3.5 rounded-xl border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/60 transition-all flex items-start space-x-3 group cursor-pointer shadow-2xs hover:shadow-sm"
            >
              <div className="p-2.5 bg-blue-100 text-blue-700 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors shrink-0 mt-0.5">
                <ArrowDownRight size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900 group-hover:text-blue-700 transition-colors">
                    เอกสาร Mutation IN
                  </h4>
                  <span className="text-[10px] font-mono font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                    FP-OP-005-001
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  MUTATION-IN OF MEDICAL DEVICE FORM (แบบฟอร์มรับเครื่องมือแพทย์เข้าสู่ระบบ)
                </p>
              </div>
            </button>

            {/* Option 2: เอกสาร Inspection */}
            <button
              type="button"
              onClick={() => setDocType('inspection')}
              className="w-full text-left p-3.5 rounded-xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/60 transition-all flex items-start space-x-3 group cursor-pointer shadow-2xs hover:shadow-sm"
            >
              <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-colors shrink-0 mt-0.5">
                <ClipboardCheck size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900 group-hover:text-emerald-700 transition-colors">
                    เอกสาร Inspection
                  </h4>
                  <span className="text-[10px] font-mono font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                    FP-OP-005-005
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  Medical Equipment testing, installation and commissioning form (แบบตรวจรับและทดสอบสภาพเครื่อง)
                </p>
              </div>
            </button>
          </div>

          {/* Dialog Footer */}
          <div className="px-4 py-3 bg-slate-100 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors border border-slate-300 cursor-pointer"
            >
              ยกเลิก
            </button>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. หน้าต่างแสดงผลเอกสารสำหรับสั่งพิมพ์ (Document Print Preview Modal)
  // =========================================================================
  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden my-4 border border-slate-200 print-clean-page animate-fade-in flex flex-col max-h-[95vh]">
        {/* Modal Action Header (Hidden when printing) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-6 py-3 bg-slate-900 text-white gap-3 shrink-0 print:hidden">
          <div className="flex items-center space-x-3">
            {equipment && (
              <button
                type="button"
                onClick={() => setDocType(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700 cursor-pointer"
                title="ย้อนกลับไปเลือกเอกสาร (Mutation IN / Inspection)"
              >
                <ArrowLeft size={16} />
              </button>
            )}

            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm sm:text-base">
                  {docType === 'mutation_in'
                    ? 'MUTATION-IN OF MEDICAL DEVICE FORM'
                    : docType === 'inspection'
                    ? 'Medical Equipment testing, installation and commissioning form'
                    : 'รายงานทะเบียนเครื่องมือแพทย์'}
                </span>
                {equipment && (
                  <span className="bg-blue-600/40 text-blue-300 px-2 py-0.5 rounded text-xs font-mono font-semibold">
                    {equipment.code}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              disabled={isPrinting}
              className="flex items-center space-x-1.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-400 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs cursor-pointer"
              title="สั่งพิมพ์ไปยังเครื่องพิมพ์"
            >
              {isPrinting ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>กำลังส่ง...</span>
                </>
              ) : (
                <>
                  <Printer size={14} />
                  <span>สั่งพิมพ์ (Print)</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              title="ปิดหน้าต่าง"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet View Area */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-4 bg-slate-200 flex justify-center">
          <div ref={printContentRef} className="w-full max-w-[794px] bg-white print:bg-white text-black font-sans leading-tight">
            
            {/* ========================================================================= */}
            {/* DOCUMENT A: MUTATION-IN OF MEDICAL DEVICE FORM (100% Exact to PDF Image) */}
            {/* ========================================================================= */}
            {docType === 'mutation_in' && equipment && (
              <div 
                className="bg-white p-4 sm:p-6 text-black print:p-4 mx-auto"
                style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
              >
                {/* Rectangular Border Frame */}
                <div className="border-[1.5px] border-black">
                  {/* Top Header & Device Info Area */}
                  <div className="p-3 sm:p-4 pb-2">
                    {/* 1. Header with Title and Logo */}
                    <div className="flex items-start justify-between pb-3 relative">
                      <div className="w-16"></div> {/* Spacer for symmetry */}
                      <div className="flex-1 text-center">
                        <h1 className="text-[15px] sm:text-[16px] font-black uppercase tracking-wide text-black">
                          MUTATION-IN OF MEDICAL DEVICE FORM
                        </h1>
                      </div>
                      {/* +ITRIS Logo */}
                      <div className="flex items-center space-x-1 shrink-0">
                        <div className="w-5 h-5 bg-[#d91e18] flex items-center justify-center text-white font-black text-sm leading-none rounded-[2px]">
                          +
                        </div>
                        <span className="text-xl font-black italic text-[#d91e18] tracking-tighter" style={{ fontFamily: 'Arial Black, Arial, sans-serif' }}>
                          iTRiS
                        </span>
                      </div>
                    </div>

                    {/* 2. Top Device Information Header */}
                    <div className="space-y-2 pt-1">
                      <div className="flex items-baseline gap-2 text-[10px]">
                        <div className="flex items-baseline flex-1 min-w-0">
                          <span className="font-bold whitespace-nowrap mr-1">DEVICE NAME*:</span>
                          <span className="border-b border-black flex-1 font-semibold text-black px-1 truncate">
                            {equipment.name}
                          </span>
                        </div>
                        <div className="flex items-baseline w-48 shrink-0">
                          <span className="font-bold whitespace-nowrap mr-1">UMNDS CODE*:</span>
                          <span className="border-b border-black flex-1 font-mono font-medium text-black px-1">
                            {equipment.umdnsCode || equipment.itrisId || ''}
                          </span>
                        </div>
                        <div className="flex items-baseline w-36 shrink-0">
                          <span className="font-bold whitespace-nowrap mr-1">DATE*:</span>
                          <span className="border-b border-black flex-1 font-medium text-black px-1 text-center">
                            {equipment.registrationDate ? formatDateSlash(equipment.registrationDate) : formattedToday}
                          </span>
                        </div>
                      </div>

                      {/* Ownership Checkboxes (Single-choice / Mutually Exclusive) */}
                      <div className="flex items-center text-[9px] pt-1">
                        <CheckSquare 
                          checked={ownership === 'hospital'} 
                          onClick={() => setOwnership('hospital')} 
                          label="HOSPITAL OWNED" 
                        />
                        <CheckSquare 
                          checked={ownership === 'leased'} 
                          onClick={() => setOwnership('leased')} 
                          label="LEASED DEVICE" 
                        />
                        <CheckSquare 
                          checked={ownership === 'profit_sharing'} 
                          onClick={() => setOwnership('profit_sharing')} 
                          label="PROFIT SHARING" 
                        />
                        <div className="flex items-baseline flex-1 min-w-0">
                          <span 
                            onClick={() => setOwnership('other')}
                            className={`font-medium mr-1 whitespace-nowrap cursor-pointer hover:opacity-75 select-none ${ownership === 'other' ? 'font-bold' : ''}`}
                            title="เลือก OTHER"
                          >
                            OTHER:
                          </span>
                          <span className="border-b border-black flex-1 px-1 min-h-[14px] flex items-center">
                            <input
                              type="text"
                              value={otherOwnershipText}
                              onChange={(e) => {
                                setOtherOwnershipText(e.target.value);
                                if (e.target.value.trim()) {
                                  setOwnership('other');
                                }
                              }}
                              onFocus={() => setOwnership('other')}
                              placeholder=""
                              className="w-full bg-transparent outline-none text-[9px] text-black font-medium print:hidden"
                            />
                            <span className="hidden print:inline text-[9px]">
                              {ownership === 'other' ? otherOwnershipText : ''}
                            </span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 3. Main 2-Column Body */}
                  <div className="border-t-[1.5px] border-black flex">
                  {/* ========================================= */}
                  {/* LEFT COLUMN                               */}
                  {/* ========================================= */}
                  <div className="w-1/2 border-r-[1.5px] border-black text-[9.5px] flex flex-col">
                    
                    {/* 1. CODE / ASSET NO / PO NO */}
                    <div className="p-2 pb-[15px] space-y-1.5 border-b border-black">
                      <div className="flex items-center">
                        <span className="w-[78px] shrink-0 font-bold whitespace-nowrap">CODE*:</span>
                        <span className="border-b border-black flex-1 font-mono font-bold text-black px-1 min-h-[16px] flex items-center">
                          {equipment.code}
                        </span>
                        <div className="w-10 shrink-0"></div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center flex-1 min-w-0">
                          <span className="w-[78px] shrink-0 font-bold whitespace-nowrap">ASSET NO.:</span>
                          <span className="border-b border-black flex-1 font-mono px-1 min-h-[16px] flex items-center truncate">
                            {equipment.assetNo || ''}
                          </span>
                        </div>
                        <div className="w-10 shrink-0 flex justify-end">
                          <RadioCircle label="N/A" checked={!equipment.assetNo} className="mr-0" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center flex-1 min-w-0">
                          <span className="w-[78px] shrink-0 font-bold whitespace-nowrap">PO/CTX NO.:</span>
                          <span className="border-b border-black flex-1 font-mono px-1 min-h-[16px] flex items-center truncate">
                            {equipment.poNo || ''}
                          </span>
                        </div>
                        <div className="w-10 shrink-0 flex justify-end">
                          <RadioCircle label="N/A" checked={!equipment.poNo} className="mr-0" />
                        </div>
                      </div>
                    </div>

                    {/* 2. CLASSIFICATION / CLINICAL ALARM / RISK LEVEL */}
                    <div className="p-2 pb-[18px] space-y-2 border-b border-black">
                      <div>
                        <div className="font-bold mb-1.5">CLASSIFICATION*</div>
                        <div className="grid grid-cols-2 gap-y-1.5 gap-x-2 pl-1">
                          <RadioCircle 
                            label="LIFE SUPPORT OR RESC" 
                            checked={classificationChoice === 'LIFE SUPPORT OR RESC'} 
                            onClick={() => setClassificationChoice('LIFE SUPPORT OR RESC')} 
                          />
                          <RadioCircle 
                            label="DIAGNOSTIC" 
                            checked={classificationChoice === 'DIAGNOSTIC'} 
                            onClick={() => setClassificationChoice('DIAGNOSTIC')} 
                          />
                          <RadioCircle 
                            label="CRITICAL MONITORING" 
                            checked={classificationChoice === 'CRITICAL MONITORING'} 
                            onClick={() => setClassificationChoice('CRITICAL MONITORING')} 
                          />
                          <RadioCircle 
                            label="ENERGY-EMITTING" 
                            checked={classificationChoice === 'ENERGY-EMITTING'} 
                            onClick={() => setClassificationChoice('ENERGY-EMITTING')} 
                          />
                          <RadioCircle 
                            label="THERAPEUTIC" 
                            checked={classificationChoice === 'THERAPEUTIC'} 
                            onClick={() => setClassificationChoice('THERAPEUTIC')} 
                          />
                          <RadioCircle 
                            label="MISC OTHER" 
                            checked={classificationChoice === 'MISC OTHER'} 
                            onClick={() => setClassificationChoice('MISC OTHER')} 
                          />
                        </div>
                      </div>

                      <div className="flex items-center pt-0.5">
                        <span className="w-[105px] shrink-0 font-bold whitespace-nowrap">CLINICAL ALARM</span>
                        <div className="flex items-center space-x-3">
                          <RadioCircle 
                            label="YES" 
                            checked={clinicalAlarmChoice === 'YES'} 
                            onClick={() => setClinicalAlarmChoice('YES')} 
                            className="mr-0"
                          />
                          <RadioCircle 
                            label="NO" 
                            checked={clinicalAlarmChoice === 'NO'} 
                            onClick={() => setClinicalAlarmChoice('NO')} 
                            className="mr-0"
                          />
                          <RadioCircle 
                            label="UNKNOWN" 
                            checked={clinicalAlarmChoice === 'UNKNOWN'} 
                            onClick={() => setClinicalAlarmChoice('UNKNOWN')} 
                            className="mr-0"
                          />
                        </div>
                      </div>

                      <div className="flex items-center pt-0.5">
                        <span className="w-[105px] shrink-0 font-bold whitespace-nowrap">RISK LEVEL*</span>
                        <div className="flex items-center space-x-3">
                          <RadioCircle 
                            label="HIGH" 
                            checked={riskLevelChoice === 'HIGH'} 
                            onClick={() => setRiskLevelChoice('HIGH')} 
                            className="mr-0"
                          />
                          <RadioCircle 
                            label="MEDUIM" 
                            checked={riskLevelChoice === 'MEDUIM'} 
                            onClick={() => setRiskLevelChoice('MEDUIM')} 
                            className="mr-0"
                          />
                          <RadioCircle 
                            label="LOW" 
                            checked={riskLevelChoice === 'LOW'} 
                            onClick={() => setRiskLevelChoice('LOW')} 
                            className="mr-0"
                          />
                        </div>
                      </div>
                    </div>

                    {/* 3. MANUFACTURER / MODEL / SERIAL NO. (Grouped in one box) */}
                    <div className="p-2 pb-[7px] space-y-1.5 border-b border-black">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center flex-1 mr-2 min-w-0">
                          <span className="w-[96px] shrink-0 font-bold whitespace-nowrap">MANUFACTURER</span>
                          <span className="border-b border-black flex-1 px-1 font-medium min-h-[16px] flex items-center truncate">
                            {equipment.manufacturer || ''}
                          </span>
                        </div>
                        <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                          <RadioCircle label="N/A" className="mr-0" />
                          <RadioCircle label="UNKNOWN" checked={!equipment.manufacturer} className="mr-0" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center flex-1 mr-2 min-w-0">
                          <span className="w-[96px] shrink-0 font-bold whitespace-nowrap">MODEL</span>
                          <span className="border-b border-black flex-1 px-1 font-medium min-h-[16px] flex items-center truncate">
                            {equipment.model || ''}
                          </span>
                        </div>
                        <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                          <RadioCircle label="N/A" className="mr-0" />
                          <RadioCircle label="UNKNOWN" checked={!equipment.model} className="mr-0" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center flex-1 mr-2 min-w-0">
                          <span className="w-[96px] shrink-0 font-bold whitespace-nowrap">SERIAL NO.</span>
                          <span className="border-b border-black flex-1 px-1 font-mono font-medium min-h-[16px] flex items-center truncate">
                            {equipment.serialNumber || ''}
                          </span>
                        </div>
                        <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                          <RadioCircle label="N/A" className="mr-0" />
                          <RadioCircle label="UNKNOWN" checked={!equipment.serialNumber} className="mr-0" />
                        </div>
                      </div>
                    </div>

                    {/* 6. SOFTWARE */}
                    <div className="p-2 border-b border-black space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">SOFTWARE</span>
                        <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                          <RadioCircle label="N/A" checked={true} className="mr-0" />
                          <RadioCircle label="UNKNOWN" className="mr-0" />
                        </div>
                      </div>
                      <div className="flex items-center pl-2">
                        <span className="w-18 shrink-0 font-medium whitespace-nowrap">VERSION:</span>
                        <span className="border-b border-black flex-1 px-1 min-h-[16px]">&nbsp;</span>
                      </div>
                      <div className="flex items-center pl-2">
                        <span className="w-18 shrink-0 font-medium whitespace-nowrap">REV. NO.:</span>
                        <span className="border-b border-black flex-1 px-1 min-h-[16px]">&nbsp;</span>
                      </div>
                    </div>

                    {/* 7. ASSOCIATED ACCESSORIES */}
                    <div className="p-2 border-b border-black space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">ASSOCIATED ACCESSORIES</span>
                        <RadioCircle label="NON" checked={!equipment.accessories} className="mr-0" />
                      </div>
                      <div className="border-b border-black min-h-[16px] text-[9px] px-1 font-medium flex items-center truncate">
                        {equipment.accessories || ''}
                      </div>
                      <div className="border-b border-black min-h-[16px]">&nbsp;</div>
                    </div>

                    {/* 8. CONSUMABLES USED */}
                    <div className="p-2 border-b border-black space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">CONSUMABLES USED</span>
                        <RadioCircle label="NON" checked={!equipment.consumables} className="mr-0" />
                      </div>
                      <div className="border-b border-black min-h-[16px] text-[9px] px-1 font-medium flex items-center truncate">
                        {equipment.consumables || ''}
                      </div>
                      <div className="border-b border-black min-h-[16px]">&nbsp;</div>
                    </div>

                    {/* 9. INSTALLATION DATE */}
                    <div className="p-2 border-b border-black flex items-center justify-between">
                      <div className="flex items-center flex-1 mr-2 min-w-0">
                        <span className="w-[110px] shrink-0 font-bold whitespace-nowrap">INSTALLATION DATE</span>
                        <span className="border-b border-black flex-1 px-1 font-mono text-center min-h-[16px] flex items-center justify-center">
                          {formatDateSlash(equipment.installationDate)}
                        </span>
                      </div>
                      <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                        <RadioCircle label="N/A" className="mr-0" />
                        <RadioCircle label="UNKNOWN" checked={!equipment.installationDate} className="mr-0" />
                      </div>
                    </div>

                    {/* 10. PURCHASE DATE* */}
                    <div className="p-1.5 h-[60px] border-b border-black flex flex-col justify-between">
                      <div className="font-bold text-[8.5px]">PURCHASE DATE*</div>
                      <div className="border-b border-black min-h-[16px] px-1 font-mono font-medium flex items-center">
                        {formatDateSlash(equipment.purchaseDate)}
                      </div>
                    </div>

                    {/* 11. VENDOR NAME */}
                    <div className="p-1.5 h-[60px] border-b border-black flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[8.5px]">VENDOR NAME</span>
                        <div className="w-28 shrink-0 flex items-center justify-end space-x-2">
                          <RadioCircle label="N/A" className="mr-0" />
                          <RadioCircle label="UNKNOWN" checked={!equipment.vendorCompany} className="mr-0" />
                        </div>
                      </div>
                      <div className="border-b border-black min-h-[16px] px-1 font-medium flex items-center truncate">
                        {equipment.vendorCompany || ''}
                      </div>
                    </div>

                    {/* 12. PURCHASE PRICE* */}
                    <div className="p-1.5 h-[60px] flex flex-col justify-between">
                      <div className="font-bold text-[8.5px]">PURCHASE PRICE*</div>
                      <div className="border-b border-black min-h-[16px] px-1 font-mono font-semibold flex items-center">
                        {formatPurchasePrice(equipment.purchase)}
                      </div>
                    </div>

                  </div>

                  {/* ========================================= */}
                  {/* RIGHT COLUMN                              */}
                  {/* ========================================= */}
                  <div className="w-1/2 text-[9.5px]">
                    
                    {/* DEPARTMENT* */}
                    <div className="p-2 border-b border-black space-y-1.5">
                      <div className="font-bold">DEPARTMENT*</div>
                      <div className="flex items-baseline pl-3">
                        <span className="font-medium whitespace-nowrap mr-1 w-24">Full Name:</span>
                        <span className="border-b border-black flex-1 px-1 font-semibold">
                          {equipment.department || ''}
                        </span>
                      </div>
                      <div className="flex items-baseline pl-3">
                        <span className="font-medium whitespace-nowrap mr-1 w-24">Abbreviation:</span>
                        <span className="border-b border-black flex-1 px-1 font-mono">
                          {equipment.deptAbbreviation || (equipment.department ? equipment.department.slice(0, 5).toUpperCase() : '')}
                        </span>
                      </div>
                      <div className="flex items-baseline pl-3">
                        <span className="font-medium whitespace-nowrap mr-1 w-32">Cost Center/Dept. Code*:</span>
                        <span className="border-b border-black flex-1 px-1 font-mono">
                          {equipment.costCenter || ''}
                        </span>
                      </div>
                    </div>

                    {/* LOCATION* */}
                    <div className="p-2 border-b border-black space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">LOCATION*:</span>
                        <div className="flex items-center">
                          <RadioCircle label="FIX" />
                          <RadioCircle label="MOVABLE" checked={true} />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 pl-2">
                        <div className="flex items-baseline">
                          <span className="font-medium mr-1">Building:</span>
                          <span className="border-b border-black flex-1 px-1 truncate">
                            {equipment.building || ''}
                          </span>
                        </div>
                        <div className="flex items-baseline">
                          <span className="font-medium mr-1">Floor:</span>
                          <span className="border-b border-black flex-1 px-1 truncate">
                            {equipment.floor || ''}
                          </span>
                        </div>
                        <div className="flex items-baseline">
                          <span className="font-medium mr-1">Room:</span>
                          <span className="border-b border-black flex-1 px-1 truncate">
                            {equipment.room || equipment.department || ''}
                          </span>
                        </div>
                        <div className="flex items-baseline">
                          <span className="font-medium mr-1">Station:</span>
                          <span className="border-b border-black flex-1 px-1 truncate">
                            {equipment.station || ''}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* INSPECTION FREQUENCY */}
                    <div className="p-2 border-b border-black space-y-1">
                      <div className="font-bold">INSPECTION FREQUENCY <span className="font-normal">(times per year)</span></div>
                      <div className="flex items-center pl-2 pt-0.5">
                        <RadioCircle label="1 / Year" checked={true} />
                        <RadioCircle label="2 / Year" />
                      </div>
                      <div className="flex items-center pl-2">
                        <RadioCircle label="3 / Year" />
                        <div className="flex items-baseline flex-1 min-w-0">
                          <RadioCircle label="Other" />
                          <span className="border-b border-black flex-1 px-1">&nbsp;</span>
                        </div>
                      </div>
                    </div>

                    {/* OPERATION MANUAL / SERVICE MANUAL */}
                    <div className="p-2 border-b border-black space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">OPERATION MANUAL</span>
                        <div className="flex items-center">
                          <RadioCircle label="No" />
                          <RadioCircle label="Yes" checked={true} />
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-0.5">
                        <span className="font-bold">SERVICE MANUAL</span>
                        <div className="flex items-center">
                          <RadioCircle label="No" />
                          <RadioCircle label="Yes" checked={true} />
                        </div>
                      </div>
                    </div>

                    {/* WARRANTY */}
                    <div className="p-2 border-b border-black flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="font-bold mr-2">WARRANTY</span>
                        <RadioCircle label="No" checked={!equipment.warrantyPeriod && !equipment.warrantyYears} />
                        <RadioCircle label="Yes" checked={Boolean(equipment.warrantyPeriod || equipment.warrantyYears)} />
                      </div>
                      <div className="flex items-baseline flex-1 ml-2 min-w-0">
                        <span className="font-bold whitespace-nowrap mr-1">EXPIRATION DATE</span>
                        <span className="border-b border-black flex-1 px-1 font-mono text-center">
                          {warrantyExpiration || ''}
                        </span>
                      </div>
                    </div>

                    {/* SERVICE AFTER WARRANTY */}
                    <div className="p-2 border-b border-black flex items-center justify-between">
                      <span className="font-bold">SERVICE AFTER WARRANTY</span>
                      <div className="flex items-center">
                        <RadioCircle label="No" />
                        <RadioCircle label="Yes" checked={true} />
                      </div>
                    </div>

                    {/* STICKERS IN PLACE* */}
                    <div className="p-2 pb-[6px] border-b border-black space-y-1">
                      <div className="font-bold">STICKERS IN PLACE*</div>
                      <div className="grid grid-cols-2 gap-y-1 gap-x-1 pl-2">
                        <RadioCircle label="Code" checked={true} />
                        <RadioCircle label="Inspection" checked={true} />
                        <RadioCircle label="Preventive Maintenance" checked={true} />
                        <RadioCircle label="Hospital Asset No." checked={true} />
                        <RadioCircle label="Calibration" checked={true} />
                      </div>
                    </div>

                    {/* EQUIPMENT CONDITION (STATUS)* */}
                    <div className="p-2 pb-[11px] border-b border-black space-y-1">
                      <div className="font-bold">EQUIPMENT CONDITION (STATUS)*</div>
                      <div className="flex items-center pl-2 pt-0.5">
                        <RadioCircle label="NEW" checked={equipment.status === 'active'} />
                        <RadioCircle label="RE-INVENTORY" checked={equipment.status !== 'active'} />
                      </div>
                    </div>

                    {/* COMMENTS */}
                    <div className="p-2 border-b border-black space-y-1">
                      <div className="font-bold">COMMENTS</div>
                      <div className="border-b border-black min-h-[14px] text-[8.5px] px-1 flex items-center">
                        <input
                          type="text"
                          value={commentLine1}
                          onChange={(e) => setCommentLine1(e.target.value)}
                          placeholder="พิมพ์ข้อความ..."
                          className="w-full bg-transparent outline-none text-[8.5px] text-black font-normal print:hidden placeholder:text-slate-400"
                        />
                        <span className="hidden print:inline text-[8.5px] text-black">
                          {commentLine1 || ''}
                        </span>
                      </div>
                      <div className="border-b border-black min-h-[14px] text-[8.5px] px-1 flex items-center">
                        <input
                          type="text"
                          value={commentLine2}
                          onChange={(e) => setCommentLine2(e.target.value)}
                          placeholder=""
                          className="w-full bg-transparent outline-none text-[8.5px] text-black font-normal print:hidden"
                        />
                        <span className="hidden print:inline text-[8.5px] text-black">
                          {commentLine2 || ''}
                        </span>
                      </div>
                    </div>

                    {/* 4. SIGNATURES BLOCK (Right side 2x3 block matching example) */}
                    <div>
                      {/* Row 1: SIGNATURES: (left) | ITRIS ENGINEER* (right) */}
                      <div className="flex border-b border-black text-[9px] h-[60px]">
                        {/* SIGNATURES: */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-start border-r border-black">
                          <span className="font-bold text-[8.5px]">
                            <u className="underline font-bold">SIGNATURES:</u>
                          </span>
                        </div>

                        {/* ITRIS ENGINEER* */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-between relative">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-[8.5px]">ITRIS ENGINEER*</span>
                            <div className="print:hidden flex items-center space-x-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenSigning('itris_engineer', 'ITRIS ENGINEER*', currentUser || 'ITRIS Biomedical Engineer')}
                                className="text-[8px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-1.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-0.5 cursor-pointer font-medium"
                                title="กดเซ็นลายเซ็น ITRIS ENGINEER"
                              >
                                <PenLine size={8} />
                                <span>{signatures['itris_engineer'] ? 'แก้ไข' : 'เซ็น'}</span>
                              </button>
                              {signatures['itris_engineer'] && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSignature('itris_engineer')}
                                  className="text-slate-400 hover:text-rose-600 p-0.5 rounded"
                                  title="ลบลายเซ็น"
                                >
                                  <Trash2 size={9} />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="flex-1 flex flex-col items-center justify-center my-0.5">
                            {signatures['itris_engineer'] ? (
                              <div className="flex flex-col items-center justify-center">
                                <img 
                                  src={signatures['itris_engineer'].signature} 
                                  alt="ITRIS ENGINEER signature" 
                                  className="max-h-[30px] max-w-[120px] object-contain" 
                                />
                                <div className="text-[7.5px] text-slate-800 font-medium leading-none mt-0.5">
                                  ({signatures['itris_engineer'].name || 'ลงชื่อแล้ว'})
                                </div>
                              </div>
                            ) : (
                              <div className="border-b border-black/30 w-3/4 pb-0.5 text-center text-[7.5px] text-slate-400">
                                (ลงชื่อ / วันที่)
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Row 2: MANAGER* (left) | DEPARTMENT* (right) */}
                      <div className="flex border-b border-black text-[9px] h-[60px]">
                        {/* MANAGER* */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-between border-r border-black relative">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-[8.5px]">MANAGER*</span>
                            <div className="print:hidden flex items-center space-x-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenSigning('manager', 'MANAGER*', 'ผู้จัดการ')}
                                className="text-[8px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-1.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-0.5 cursor-pointer font-medium"
                                title="กดเพื่อเซ็นลายเซ็น MANAGER"
                              >
                                <PenLine size={8} />
                                <span>{signatures['manager'] ? 'แก้ไข' : 'เซ็น'}</span>
                              </button>
                              {signatures['manager'] && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSignature('manager')}
                                  className="text-slate-400 hover:text-rose-600 p-0.5 rounded"
                                  title="ลบลายเซ็น"
                                >
                                  <Trash2 size={9} />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="flex-1 flex flex-col items-center justify-center my-0.5">
                            {signatures['manager'] ? (
                              <div className="flex flex-col items-center justify-center">
                                <img 
                                  src={signatures['manager'].signature} 
                                  alt="MANAGER signature" 
                                  className="max-h-[30px] max-w-[120px] object-contain" 
                                />
                                <div className="text-[7.5px] text-slate-800 font-medium leading-none mt-0.5">
                                  ({signatures['manager'].name || 'ลงชื่อแล้ว'})
                                </div>
                              </div>
                            ) : (
                              <div className="border-b border-black/30 w-3/4 pb-0.5 text-center text-[7.5px] text-slate-400">
                                (ลงชื่อ / วันที่)
                              </div>
                            )}
                          </div>
                        </div>

                        {/* DEPARTMENT* */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-between relative">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-[8.5px]">DEPARTMENT*</span>
                            <div className="print:hidden flex items-center space-x-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenSigning('department', 'DEPARTMENT*', equipment.department || 'หัวหน้าแผนก')}
                                className="text-[8px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-1.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-0.5 cursor-pointer font-medium"
                                title="กดเพื่อเซ็นลายเซ็น DEPARTMENT"
                              >
                                <PenLine size={8} />
                                <span>{signatures['department'] ? 'แก้ไข' : 'เซ็น'}</span>
                              </button>
                              {signatures['department'] && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSignature('department')}
                                  className="text-slate-400 hover:text-rose-600 p-0.5 rounded"
                                  title="ลบลายเซ็น"
                                >
                                  <Trash2 size={9} />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="flex-1 flex flex-col items-center justify-center my-0.5">
                            {signatures['department'] ? (
                              <div className="flex flex-col items-center justify-center">
                                <img 
                                  src={signatures['department'].signature} 
                                  alt="DEPARTMENT signature" 
                                  className="max-h-[30px] max-w-[120px] object-contain" 
                                />
                                <div className="text-[7.5px] text-slate-800 font-medium leading-none mt-0.5">
                                  ({signatures['department'].name || 'ลงชื่อแล้ว'})
                                </div>
                              </div>
                            ) : (
                              <div className="border-b border-black/30 w-3/4 pb-0.5 text-center text-[7.5px] text-slate-400">
                                (ลงชื่อ / วันที่)
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Row 3: BME* (left) | ADMIN* (right) */}
                      <div className="flex text-[9px] h-[60px]">
                        {/* BME* */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-between border-r border-black relative">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-[8.5px]">BME*</span>
                            <div className="print:hidden flex items-center space-x-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenSigning('bme', 'BME*', 'วิศวกรชีวการแพทย์')}
                                className="text-[8px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-1.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-0.5 cursor-pointer font-medium"
                                title="กดเพื่อเซ็นลายเซ็น BME"
                              >
                                <PenLine size={8} />
                                <span>{signatures['bme'] ? 'แก้ไข' : 'เซ็น'}</span>
                              </button>
                              {signatures['bme'] && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSignature('bme')}
                                  className="text-slate-400 hover:text-rose-600 p-0.5 rounded"
                                  title="ลบลายเซ็น"
                                >
                                  <Trash2 size={9} />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="flex-1 flex flex-col items-center justify-center my-0.5">
                            {signatures['bme'] ? (
                              <div className="flex flex-col items-center justify-center">
                                <img 
                                  src={signatures['bme'].signature} 
                                  alt="BME signature" 
                                  className="max-h-[30px] max-w-[120px] object-contain" 
                                />
                                <div className="text-[7.5px] text-slate-800 font-medium leading-none mt-0.5">
                                  ({signatures['bme'].name || 'ลงชื่อแล้ว'})
                                </div>
                              </div>
                            ) : (
                              <div className="border-b border-black/30 w-3/4 pb-0.5 text-center text-[7.5px] text-slate-400">
                                (ลงชื่อ / วันที่)
                              </div>
                            )}
                          </div>
                        </div>

                        {/* ADMIN* */}
                        <div className="w-1/2 p-1.5 flex flex-col justify-between relative">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-[8.5px]">ADMIN*</span>
                            <div className="print:hidden flex items-center space-x-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenSigning('admin', 'ADMIN*', 'เจ้าหน้าที่แอดมิน')}
                                className="text-[8px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-1.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-0.5 cursor-pointer font-medium"
                                title="กดเพื่อเซ็นลายเซ็น ADMIN"
                              >
                                <PenLine size={8} />
                                <span>{signatures['admin'] ? 'แก้ไข' : 'เซ็น'}</span>
                              </button>
                              {signatures['admin'] && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSignature('admin')}
                                  className="text-slate-400 hover:text-rose-600 p-0.5 rounded"
                                  title="ลบลายเซ็น"
                                >
                                  <Trash2 size={9} />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="flex-1 flex flex-col items-center justify-center my-0.5">
                            {signatures['admin'] ? (
                              <div className="flex flex-col items-center justify-center">
                                <img 
                                  src={signatures['admin'].signature} 
                                  alt="ADMIN signature" 
                                  className="max-h-[30px] max-w-[120px] object-contain" 
                                />
                                <div className="text-[7.5px] text-slate-800 font-medium leading-none mt-0.5">
                                  ({signatures['admin'].name || 'ลงชื่อแล้ว'})
                                </div>
                              </div>
                            ) : (
                              <div className="border-b border-black/30 w-3/4 pb-0.5 text-center text-[7.5px] text-slate-400">
                                (ลงชื่อ / วันที่)
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

              {/* 5. Document Footer Notice (OUTSIDE the rectangular frame) */}
              <div className="pt-2 px-0.5 flex items-center text-[8.5px] text-black">
                <div className="w-1/2 font-mono">FP-OP-005-001</div>
                <div className="w-1/2 font-sans italic text-slate-900">* mandatory field</div>
              </div>
            </div>
          )}

            {/* ========================================================================= */}
            {/* DOCUMENT B: INSPECTION REPORT (FP-OP-005-005) - 100% Replica from PDF      */}
            {/* Medical Equipment testing, installation and commissioning form             */}
            {/* ========================================================================= */}
            {docType === 'inspection' && equipment && (
              <div 
                className="bg-white p-6 sm:p-8 text-black print:p-6 mx-auto"
                style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
              >
                {/* 1. Header with ITRIS Logo */}
                <div className="flex items-center space-x-2 mb-3">
                  <span className="text-3xl font-black italic text-[#d91e18] tracking-tight" style={{ fontFamily: 'Arial Black, Arial, sans-serif' }}>
                    iTRiS
                  </span>
                  <span className="text-xl italic font-bold text-[#55595c] tracking-tight">
                    MEDICAL (Thailand) Co., Ltd.
                  </span>
                </div>

                {/* 2. Main Title Banner */}
                <div className="bg-[#54595f] text-white text-center py-1.5 px-4 font-bold text-[13px] tracking-wide rounded-[2px] mb-3">
                  Medical Equipment testing, installation and commissioning form
                </div>

                {/* 3. Medical Equipment Information Table */}
                <div className="border border-black mb-3">
                  <table className="w-full border-collapse text-[10px]">
                    <tbody>
                      <tr className="border-b border-black">
                        <td className="p-1.5 border-r border-black w-1/2 align-top">
                          <div className="text-black font-medium">Medical Equipment</div>
                          <div className="font-bold text-black text-[11px] pt-0.5">{equipment.name}</div>
                        </td>
                        <td className="p-1.5 w-1/2 align-top">
                          <div className="text-black font-medium">Department</div>
                          <div className="font-semibold text-black text-[11px] pt-0.5">{equipment.department || '-'}</div>
                        </td>
                      </tr>
                      <tr className="border-b border-black">
                        <td className="p-1.5 border-r border-black align-top">
                          <div className="text-black font-medium">UMDNS Description</div>
                          <div className="font-mono text-black pt-0.5">{equipment.umdnsCode || equipment.itrisId || '-'}</div>
                        </td>
                        <td className="p-1.5 align-top">
                          <div className="text-black font-medium">Date</div>
                          <div className="font-medium text-black pt-0.5">
                            {formatDateSlash(equipment.installationDate || equipment.registrationDate) || formattedToday}
                          </div>
                        </td>
                      </tr>
                      <tr className="border-b border-black">
                        <td className="p-1.5 border-r border-black align-top">
                          <div className="text-black font-medium">Manufacturer</div>
                          <div className="font-medium text-black pt-0.5">{equipment.manufacturer || '-'}</div>
                        </td>
                        <td className="p-1.5 align-top">
                          <div className="text-black font-medium">Serial Number</div>
                          <div className="font-mono font-semibold text-black pt-0.5">{equipment.serialNumber || '-'}</div>
                        </td>
                      </tr>
                      <tr className="border-b border-black">
                        <td className="p-1.5 border-r border-black align-top">
                          <div className="text-black font-medium">Type / Model</div>
                          <div className="font-medium text-black pt-0.5">{equipment.model || '-'}</div>
                        </td>
                        <td className="p-1.5 align-top">
                          <div className="text-black font-medium">ID Number</div>
                          <div className="font-mono font-bold text-black pt-0.5">{equipment.code}</div>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-1.5 border-r border-black align-top">
                          <div className="text-black font-medium">Risk Class</div>
                          <div className="font-medium text-black pt-0.5">{equipment.riskLevel || 'Low'}</div>
                        </td>
                        <td className="p-1.5 align-top">
                          <div className="text-black font-medium">Asset Number</div>
                          <div className="font-mono text-black pt-0.5">{equipment.assetNo || equipment.code}</div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* 4. Section A: Incoming Inspection Banner */}
                <div className="bg-[#8c9096] text-white text-center py-1 px-4 font-bold text-[12px] tracking-wide rounded-[2px] mb-2">
                  A Incoming Inspection
                </div>

                {/* Section A Checklist */}
                <div className="space-y-1.5 text-[10.5px] px-2 mb-3">
                  <div className="flex items-center justify-between">
                    <span>Delivery note checks with order?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Outer packing undamaged?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Goods check with delivery note?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Goods clean, inner packing intact.</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  {/* CE / MD / LOT Box Row */}
                  <div className="flex items-center space-x-4 py-1">
                    <div className="flex items-center space-x-1.5">
                      <span className="font-semibold text-[10px]">CE</span>
                      <div className="w-16 h-5 border border-black flex items-center justify-center text-[10px] font-mono">
                        ✓
                      </div>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-semibold text-[10px]">MD</span>
                      <div className="w-16 h-5 border border-black flex items-center justify-center text-[10px] font-mono">
                        ✓
                      </div>
                    </div>
                    <div className="flex items-center space-x-1.5 flex-1 max-w-[280px]">
                      <span className="font-semibold text-[10px]">LOT</span>
                      <div className="flex-1 h-5 border border-black flex items-center px-2 text-[10px] font-mono">
                        {equipment.code}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>User manual supplied (Eng. /Thai)?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Instructions supplied (Eng. /Thai)?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Maintenance manual supplied?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Warranty document included?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Final test certificate supplied?</span>
                    <div className="flex items-center space-x-6">
                      <span className="inline-flex items-center space-x-1.5">
                        <span>yes</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5">
                        <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        <span>no</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* 5. Section B: Function Test Banner */}
                <div className="bg-[#8c9096] text-white text-center py-1 px-4 font-bold text-[12px] tracking-wide rounded-[2px] mb-2">
                  Function test
                </div>

                {/* Section B Function Test Table */}
                <div className="border border-black mb-3">
                  <div className="divide-y divide-black text-[10px]">
                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Plug in turn on (following instruction manual)</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Indicator lamps light up?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Display as described in manual?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Passes self-test routine?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Moving parts operate properly?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Knobs and switches act properly?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Check for more installing instructions in the manual</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>Last or next PM/CAL Sticker?</span>
                      </span>
                      <div className="flex items-center space-x-6 mr-1">
                        <span className="inline-flex items-center space-x-1.5">
                          <span>yes</span>
                          <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                        </span>
                        <span className="inline-flex items-center space-x-1.5">
                          <span>NO</span>
                          <span className="w-3.5 h-3.5 border border-black inline-block"></span>
                        </span>
                      </div>
                    </div>

                    <div className="p-1.5 flex items-center justify-between">
                      <span className="flex items-center">
                        <span className="mr-2 font-bold">•</span>
                        <span>ITRIS Inventory ID Sticker?</span>
                      </span>
                      <div className="flex items-center space-x-1.5 mr-1">
                        <span>OK</span>
                        <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 6. Electrical Safety Section */}
                <div className="text-[10px] space-y-1.5 mb-6 px-1">
                  <div className="font-bold">Electrical Safety:</div>
                  <div className="flex items-center space-x-2 pl-2">
                    <span className="font-bold">•</span>
                    <span>Pass</span>
                    <span className="w-3.5 h-3.5 border border-black flex items-center justify-center font-bold text-[10px]">✓</span>
                  </div>
                  <div className="flex items-center space-x-6 pl-5 pt-0.5">
                    <div className="flex items-center space-x-2">
                      <span>Ground Resistance (≤0.5Ohm):</span>
                      <div className="w-16 h-5 border border-black flex items-center justify-center font-mono text-[9.5px]">
                        -
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span>Chassis Leak Current (≤300µA):</span>
                      <div className="w-16 h-5 border border-black flex items-center justify-center font-mono text-[9.5px]">
                        -
                      </div>
                    </div>
                  </div>
                </div>

                {/* 7. Signatures Area */}
                <div className="pt-4 grid grid-cols-2 gap-8 text-[11px] mb-4">
                  {/* Left: ITRIS Biomedical Engineer */}
                  <div className="text-center space-y-1 relative">
                    <div className="print:hidden flex justify-center mb-1">
                      <button
                        type="button"
                        onClick={() => handleOpenSigning('itris_bme', 'ITRIS Biomedical Engineer', currentUser || 'ITRIS Biomedical Engineer')}
                        className="text-[9.5px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-2.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-1 cursor-pointer font-medium"
                        title="กดเซ็นลายเซ็นช่าง ITRIS"
                      >
                        <PenLine size={10} />
                        <span>{signatures['itris_bme'] ? 'แก้ไขลายเซ็น' : 'กดเซ็นลายเซ็นช่าง ITRIS'}</span>
                      </button>
                      {signatures['itris_bme'] && (
                        <button
                          type="button"
                          onClick={() => handleRemoveSignature('itris_bme')}
                          className="ml-1 text-slate-400 hover:text-rose-600 p-0.5 rounded"
                          title="ลบลายเซ็น"
                        >
                          <Trash2 size={11} />
                        </button>
                      )}
                    </div>

                    <div className="border-b border-black w-4/5 mx-auto min-h-[44px] flex flex-col items-center justify-end pb-0.5">
                      {signatures['itris_bme'] ? (
                        <div className="flex flex-col items-center justify-center">
                          <img 
                            src={signatures['itris_bme'].signature} 
                            alt="ITRIS BME signature" 
                            className="max-h-[38px] max-w-[160px] object-contain" 
                          />
                          <div className="text-[9px] text-slate-800 font-medium leading-none mt-0.5">
                            ({signatures['itris_bme'].name || 'ITRIS Engineer'}) {signatures['itris_bme'].date ? `• ${signatures['itris_bme'].date}` : ''}
                          </div>
                        </div>
                      ) : (
                        <span>&nbsp;</span>
                      )}
                    </div>
                    <div className="font-medium pt-1">ITRIS Biomedical Engineer</div>
                  </div>

                  {/* Right: Hospital / Department / Name */}
                  <div className="text-center space-y-1 relative">
                    <div className="print:hidden flex justify-center mb-1">
                      <button
                        type="button"
                        onClick={() => handleOpenSigning('hospital_dept', 'Hospital / Department / Name', equipment.department || 'ผู้รับมอบ/พยาบาลประจำแผนก')}
                        className="text-[9.5px] bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white px-2.5 py-0.5 rounded border border-blue-200 transition-colors inline-flex items-center space-x-1 cursor-pointer font-medium"
                        title="กดเซ็นลายเซ็นผู้รับมอบ"
                      >
                        <PenLine size={10} />
                        <span>{signatures['hospital_dept'] ? 'แก้ไขลายเซ็น' : 'กดเซ็นลายเซ็นผู้รับมอบ'}</span>
                      </button>
                      {signatures['hospital_dept'] && (
                        <button
                          type="button"
                          onClick={() => handleRemoveSignature('hospital_dept')}
                          className="ml-1 text-slate-400 hover:text-rose-600 p-0.5 rounded"
                          title="ลบลายเซ็น"
                        >
                          <Trash2 size={11} />
                        </button>
                      )}
                    </div>

                    <div className="border-b border-black w-4/5 mx-auto min-h-[44px] flex flex-col items-center justify-end pb-0.5">
                      {signatures['hospital_dept'] ? (
                        <div className="flex flex-col items-center justify-center">
                          <img 
                            src={signatures['hospital_dept'].signature} 
                            alt="Hospital signature" 
                            className="max-h-[38px] max-w-[160px] object-contain" 
                          />
                          <div className="text-[9px] text-slate-800 font-medium leading-none mt-0.5">
                            ({signatures['hospital_dept'].name || 'ผู้รับมอบ'}) {signatures['hospital_dept'].date ? `• ${signatures['hospital_dept'].date}` : ''}
                          </div>
                        </div>
                      ) : (
                        <span>&nbsp;</span>
                      )}
                    </div>
                    <div className="font-medium pt-1">Hospital &nbsp;/&nbsp; Department &nbsp;/&nbsp; Name</div>
                  </div>
                </div>

                {/* 8. Footer */}
                <div className="pt-2 text-[9px] font-mono text-black">
                  FP-OP-005-005
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* DOCUMENT C: LIST REGISTER VIEW                                            */}
            {/* ========================================================================= */}
            {isListView && (
              <div className="p-4 bg-white text-black font-sans text-[9px]">
                <div className="border-b-2 border-black pb-2 mb-3 flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-bold text-black uppercase">
                      ITRIS Medical (Thailand) Co., Ltd. - Equipment Master Register
                    </h2>
                    <p className="text-[10px] text-slate-600">
                      Total Devices: {equipmentList?.length} items
                    </p>
                  </div>
                  <div className="text-right text-[9px] font-mono">
                    <div>Date: {formattedToday}</div>
                    <div className="text-slate-500">Controlled Document</div>
                  </div>
                </div>

                <table className="w-full text-left border-collapse border border-black text-[9px]">
                  <thead className="bg-slate-100 border-b border-black font-bold">
                    <tr>
                      <th className="p-1 border-r border-black text-center w-8">#</th>
                      <th className="p-1 border-r border-black w-24">ID CODE</th>
                      <th className="p-1 border-r border-black w-20">Itris ID</th>
                      <th className="p-1 border-r border-black">Equipment Name</th>
                      <th className="p-1 border-r border-black w-24">Department</th>
                      <th className="p-1 border-r border-black w-20">Model</th>
                      <th className="p-1 border-r border-black w-24">Serial No.</th>
                      <th className="p-1 border-r border-black w-14 text-center">Risk</th>
                      <th className="p-1 text-center w-14">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black/30">
                    {equipmentList?.map((eq, idx) => (
                      <tr key={eq.id}>
                        <td className="p-1 text-center font-mono border-r border-black">{idx + 1}</td>
                        <td className="p-1 font-mono font-bold border-r border-black">{eq.code}</td>
                        <td className="p-1 font-mono border-r border-black">{eq.itrisId || '-'}</td>
                        <td className="p-1 font-medium border-r border-black">{eq.name}</td>
                        <td className="p-1 border-r border-black">{eq.department || '-'}</td>
                        <td className="p-1 border-r border-black">{eq.model || '-'}</td>
                        <td className="p-1 font-mono border-r border-black">{eq.serialNumber || '-'}</td>
                        <td className="p-1 text-center border-r border-black">{eq.riskLevel || '-'}</td>
                        <td className="p-1 text-center font-semibold">
                          {eq.status === 'active' ? 'Active' : eq.status}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

          </div>
        </div>
      </div>

      {/* Signature Capture Modal */}
      {signingModal && (
        <SignaturePadModal
          isOpen={Boolean(signingModal)}
          onClose={() => setSigningModal(null)}
          title={signingModal.title}
          defaultName={signingModal.defaultName}
          defaultDate={signingModal.defaultDate}
          onSave={handleSaveSignature}
        />
      )}
    </div>
  );
}

import React, { useState } from 'react';
import { useAppStore } from '../store';
import { ClipboardCheck, Pencil, Trash2, Plus, X, Check, AlertCircle } from 'lucide-react';
import { MaintenancePlan, PlanStatus } from '../types';
import { formatDateSlash } from '../utils/dateUtils';
import EquipmentSearchSelect from '../components/EquipmentSearchSelect';

export default function MaintenanceView() {
  const { equipment, maintenances, addMaintenance, updateMaintenance, deleteMaintenance, userRole } = useAppStore();
  const isAdmin = userRole === 'Super Admin' || userRole === 'Admin';
  const canEdit = isAdmin || userRole === 'PM/CAL';
  const [isAdding, setIsAdding] = useState(false);
  const [editingPlan, setEditingPlan] = useState<MaintenancePlan | null>(null);
  const [planToDelete, setPlanToDelete] = useState<MaintenancePlan | null>(null);

  const [formData, setFormData] = useState({
    equipmentId: '',
    frequency: 'ทุก 6 เดือน',
    lastDate: new Date().toISOString().split('T')[0],
    nextDate: '',
    technician: '',
    notes: '',
    status: 'pending' as PlanStatus
  });

  const [editFormData, setEditFormData] = useState({
    equipmentId: '',
    frequency: 'ทุก 6 เดือน',
    lastDate: '',
    nextDate: '',
    technician: '',
    notes: '',
    status: 'pending' as PlanStatus
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.equipmentId) return;
    addMaintenance(formData);
    setFormData({
      equipmentId: '',
      frequency: 'ทุก 6 เดือน',
      lastDate: new Date().toISOString().split('T')[0],
      nextDate: '',
      technician: '',
      notes: '',
      status: 'pending'
    });
    setIsAdding(false);
  };

  const handleStartEdit = (plan: MaintenancePlan) => {
    setEditingPlan(plan);
    setEditFormData({
      equipmentId: plan.equipmentId,
      frequency: plan.frequency,
      lastDate: plan.lastDate,
      nextDate: plan.nextDate,
      technician: plan.technician || '',
      notes: plan.notes || '',
      status: plan.status
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPlan) return;
    updateMaintenance(editingPlan.id, editFormData);
    setEditingPlan(null);
  };

  const getStatusBadge = (status: PlanStatus) => {
    switch (status) {
      case 'completed':
        return <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">เสร็จสิ้น</span>;
      case 'overdue':
        return <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">เลยกำหนด</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">รอดำเนินการ</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">การบำรุงรักษาเครื่องมือ</h2>
          <p className="text-sm text-slate-500 mt-1">จัดการและติดตามแผนการบำรุงรักษาเครื่องมือแพทย์ (PM) ({maintenances.length} รายการ)</p>
        </div>
        {canEdit && (
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2 shadow-sm"
          >
            <ClipboardCheck size={18} />
            <span>{isAdding ? 'ยกเลิก' : 'เพิ่มแผนการบำรุงรักษา'}</span>
          </button>
        )}
      </div>

      {isAdding && canEdit && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm mb-6 animate-in fade-in duration-200">
          <h3 className="text-lg font-medium text-slate-900 mb-4">เพิ่มแผนการบำรุงรักษา (PM) ใหม่</h3>
          <form onSubmit={handleAddSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                เลือกเครื่องมือแพทย์ (ค้นหารหัสเครื่อง / ชื่อเครื่อง) <span className="text-red-500">*</span>
              </label>
              <EquipmentSearchSelect
                equipment={equipment}
                selectedId={formData.equipmentId}
                onSelect={(eqId) => setFormData(prev => ({ ...prev, equipmentId: eqId }))}
                placeholder="พิมพ์ค้นหารหัสเครื่อง, ชื่อเครื่องมือ หรือแผนก..."
                required
                accentColor="blue"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">รอบการบำรุงรักษา</label>
              <select
                value={formData.frequency}
                onChange={e => setFormData({ ...formData, frequency: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              >
                <option value="ทุก 3 เดือน">ทุก 3 เดือน</option>
                <option value="ทุก 6 เดือน">ทุก 6 เดือน</option>
                <option value="ทุก 1 ปี">ทุก 1 ปี</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">สถานะ</label>
              <select
                value={formData.status}
                onChange={e => setFormData({ ...formData, status: e.target.value as PlanStatus })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              >
                <option value="pending">รอดำเนินการ</option>
                <option value="completed">เสร็จสิ้น</option>
                <option value="overdue">เลยกำหนด</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">บำรุงรักษาล่าสุด</label>
              <input
                type="date"
                required
                value={formData.lastDate}
                onChange={e => setFormData({ ...formData, lastDate: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">กำหนดครั้งถัดไป</label>
              <input
                type="date"
                required
                value={formData.nextDate}
                onChange={e => setFormData({ ...formData, nextDate: e.target.value })}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">ช่าง/ผู้รับผิดชอบ</label>
              <input
                type="text"
                value={formData.technician}
                onChange={e => setFormData({ ...formData, technician: e.target.value })}
                placeholder="ชื่อช่าง..."
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">หมายเหตุ</label>
              <textarea
                rows={2}
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                placeholder="รายละเอียดผลการบำรุงรักษา..."
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="md:col-span-2 flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
              >
                บันทึกแผน
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto max-h-[72vh] overflow-y-auto">
          <table className="w-full text-left border-separate border-spacing-0 text-sm">
            <thead className="bg-slate-50 sticky top-0 z-10 shadow-xs">
              <tr className="border-b border-slate-200 text-slate-600">
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">รหัสเครื่องมือ</th>
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">ชื่อเครื่องมือ</th>
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">แผนก</th>
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">รอบการบำรุงรักษา</th>
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">ล่าสุด / ครั้งถัดไป</th>
                <th className="px-6 py-4 font-medium bg-slate-50 border-b border-slate-200">สถานะ</th>
                {canEdit && (
                  <th className="px-6 py-4 font-medium text-right bg-slate-50 border-b border-slate-200 sticky right-0 top-0 z-20">จัดการ</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {maintenances.map(m => {
                const eq = equipment.find(e => e.id === m.equipmentId);
                return (
                  <tr key={m.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 font-mono font-semibold text-slate-900">{eq?.code || 'Unknown'}</td>
                    <td className="px-6 py-4 text-slate-800 font-medium">
                      <div>{eq?.name || 'Unknown'}</div>
                      {m.technician && <div className="text-xs text-slate-400">ช่าง: {m.technician}</div>}
                    </td>
                    <td className="px-6 py-4 text-slate-500">{eq?.department || '-'}</td>
                    <td className="px-6 py-4 text-slate-700">{m.frequency}</td>
                    <td className="px-6 py-4 text-xs font-mono">
                      <div className="text-slate-600">ล่าสุด: {formatDateSlash(m.lastDate)}</div>
                      <div className="text-blue-600 font-semibold">ถัดไป: {formatDateSlash(m.nextDate)}</div>
                    </td>
                    <td className="px-6 py-4">{getStatusBadge(m.status)}</td>
                    {canEdit && (
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => handleStartEdit(m)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="แก้ไขแผนการบำรุงรักษา"
                          >
                            <Pencil size={17} />
                          </button>
                          <button
                            onClick={() => setPlanToDelete(m)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="ลบแผนการบำรุงรักษา"
                          >
                            <Trash2 size={17} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
              {maintenances.length === 0 && (
                <tr>
                  <td colSpan={canEdit ? 7 : 6} className="px-6 py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center space-y-3">
                      <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                        <ClipboardCheck size={24} />
                      </div>
                      <p>ยังไม่มีข้อมูลการบำรุงรักษาในขณะนี้</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Modal */}
      {editingPlan && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 bg-slate-50 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">แก้ไขแผนการบำรุงรักษา (PM)</h3>
              <button onClick={() => setEditingPlan(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSaveEdit} className="p-5 space-y-3 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">รอบการบำรุงรักษา</label>
                <select
                  value={editFormData.frequency}
                  onChange={e => setEditFormData({ ...editFormData, frequency: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ทุก 3 เดือน">ทุก 3 เดือน</option>
                  <option value="ทุก 6 เดือน">ทุก 6 เดือน</option>
                  <option value="ทุก 1 ปี">ทุก 1 ปี</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">วันที่ล่าสุด</label>
                  <input
                    type="date"
                    required
                    value={editFormData.lastDate}
                    onChange={e => setEditFormData({ ...editFormData, lastDate: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">วันที่ครั้งถัดไป</label>
                  <input
                    type="date"
                    required
                    value={editFormData.nextDate}
                    onChange={e => setEditFormData({ ...editFormData, nextDate: e.target.value })}
                    className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">สถานะ</label>
                <select
                  value={editFormData.status}
                  onChange={e => setEditFormData({ ...editFormData, status: e.target.value as PlanStatus })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500"
                >
                  <option value="pending">รอดำเนินการ</option>
                  <option value="completed">เสร็จสิ้น</option>
                  <option value="overdue">เลยกำหนด</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ช่างผู้รับผิดชอบ</label>
                <input
                  type="text"
                  value={editFormData.technician}
                  onChange={e => setEditFormData({ ...editFormData, technician: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingPlan(null)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center space-x-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700"
                >
                  <Check size={15} />
                  <span>บันทึกการแก้ไข</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {planToDelete && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 bg-rose-50 border-b border-rose-100">
              <h3 className="font-bold text-slate-900 text-sm">ยืนยันการลบแผนบำรุงรักษา</h3>
              <button onClick={() => setPlanToDelete(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X size={16} />
              </button>
            </div>
            <div className="p-5 text-xs text-slate-600">
              คุณต้องการลบแผนบำรุงรักษานี้ออกจากระบบอย่างถาวรหรือไม่?
            </div>
            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setPlanToDelete(null)}
                className="px-3.5 py-1.5 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-100"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteMaintenance(planToDelete.id);
                  setPlanToDelete(null);
                }}
                className="px-3.5 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700"
              >
                ลบรายการ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
